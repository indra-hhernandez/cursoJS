//Definición de globales
var nombresPersona = ["Victor", "Omar", "Karen", "Ariel", "Omar", "David", "Esteban", "Matías", "Vlairner", "Lucy", "Ignacio", "Humberto", "Nestor", "Daniel", "Raymundo"];
var cargosCamarero = ["Encargado", "Mozo"];

var nombreComida = ["Recado Negro", "Durango en Pulque", "Del campo", "Mediterranea", "MedMex"];
var nombreEntrante = ["Arrenque a la Crema", "Cazuela de tuetano", "Carnitas de Pato", "Camarones y setas al ajillo", "Quesadillas lacandonas"];
var nombrePrincipal = ["Fetuccini Alfredo", "Ravioles rellenos", "Pastrami Kosher", "Filete de róbalo", "Pierna de ternera"];
var nombrePostre = ["Creme Brulee", "Tarta de Almendras", "Profiteroles", "Sorbete de Mango", "Cheese Cake de Guayaba"];
var nombreBebidad = ["Cisne Negro", "Via del campo", "Cucaracha", "Martini", "Flirtini"];

const NUMCOMIDAS = 5;
const NUMMESAS = 30;
const NUMCAMAREROS = 5;

function getRandomInteger(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generarDatoAleatorio(opciones) {
	var numeroAleatorio = Math.floor(Math.random() * opciones.length);
	return opciones[numeroAleatorio];
}

class Persona {
	constructor() {
		this._nombre = generarDatoAleatorio(nombresPersona);
		this._edad = getRandomInteger(20, 60);
	}
}

class Cliente extends Persona {
	constructor() {
		super();
		this._dinero = getRandomInteger(0, 1500);
	}
}

class Camarero extends Persona {
	constructor() {
		super();
		this._cargo = generarDatoAleatorio(cargosCamarero);
	}
}

class Mesa {
	constructor(id) {
		this._mesaId = id;
		this._capacidad = getRandomInteger(2, 10);
		this._ocupada = false;
		this._personas = [];
		this._ordenes = [];
	}
}

class Producto {
	constructor(nombre) {
		this._nombre = nombre;
		this._existencias = getRandomInteger(2, 20);
		this._calorias = getRandomInteger(100, 500);
		this._precio = getRandomInteger(30, 200);
	}
}

class Comida extends Producto {
	constructor(nombre, entrante, principal, postre) {
		super(nombre);
		this._entrante = generarDatoAleatorio(nombreEntrante);
		this._principal = generarDatoAleatorio(nombrePrincipal);
		this._postre = generarDatoAleatorio(nombrePostre);
	}
}

class Bebida extends Producto {
	constructor(nombre) {
		super(nombre);
		this._esAlcoholica = (getRandomInteger(1, 2) == 1) ? true : false;
		this._gradoAlcohol = getRandomInteger(3, 20);
	}
}

class Restaurante {
	constructor(nombre) {
		this._nombre = nombre;
		this._mesas = [];
		this._camareros = [];
		this._carta = new Carta();
		this._contadorMesas = 0;

		for(let i=0; i<NUMMESAS; i++){
			this._mesas.push(new Mesa(this._contadorMesas++));
		}

		for(let i=0; i<NUMCAMAREROS; i++){
			this._camareros.push(new Camarero());
		}
	}
}

class Carta {
	constructor() {
		this._comidas = [];
		this._bebidas = [];

		for(let i=0; i<NUMCOMIDAS; i++){
			this._comidas.push(new Comida(generarDatoAleatorio(nombreComida)));
			this._bebidas.push(new Bebida(generarDatoAleatorio(nombreBebidad)));
		}
	}
}

miRestaurante = new Restaurante("ComesYTeVas");