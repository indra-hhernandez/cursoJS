//Definiendo dispositivo
var Dispositivo = function(id, numero, alias) {
    this._idIphone = id;
    this._numero = numero;
    this._alias = alias;
}

Dispositivo.prototype.enviarMensaje = function() {
    var mensaje = getMensaje(this._idIphone);
    if(mensaje.mensaje.trim() != "") {
        pubsub.pub('mensaje', new Mensaje(this._idIphone, mensaje.destinatario, mensaje.mensaje, this._alias));
    }
}

Dispositivo.prototype.recibirMensaje = function(mensaje) {
    var esPropio = (mensaje._idEmisor == this._idIphone);
    var receptor = (esPropio || mensaje._idReceptor == "TODOS") ? this._idIphone : mensaje._idReceptor;
    if(receptor == this._idIphone) {
   		pintarMensaje(receptor, mensaje._mensaje, esPropio, mensaje._alias);
   	}
}

//Definiendo mensaje
var Mensaje = function(idEmisor, idReceptor, mensaje, alias) {
    this._idEmisor = idEmisor;
    this._idReceptor = idReceptor;
    this._mensaje = mensaje;
    this._alias = alias;
}

//Definiendo pubsub
var pubsub = (function() {
    var suscriptores = {};

    function subscribe(event, callback) {
        if(!suscriptores[event]) {
            var suscriptorArray = [callback];
            suscriptores[event] = suscriptorArray;
        } else {
            suscriptores[event].push(callback);
        }
    }

    function publish(event, data) {
        if(suscriptores[event]) {
            suscriptores[event].forEach(function(callback) {
                callback(data);
            });
        }
    }
    return {
        pub: publish,
        sub: subscribe
    };
}());

enviarMensaje = function(idIphone) {
	switch(idIphone) {
	    case 'iphone1':
	        dispositivo1.enviarMensaje();
	        break;
	    case 'iphone2':
	        dispositivo2.enviarMensaje();
	        break;
	    case 'iphone3':
	        dispositivo3.enviarMensaje();
	        break;
	    case 'iphone4':
	    	dispositivo4.enviarMensaje();
	    	break;
	} 
}

//Definiendo objetos
var dispositivo1 = new Dispositivo("iphone1", "55349383", "xanxo1");
var dispositivo2 = new Dispositivo("iphone2", "55097899", "xanxo2");
var dispositivo3 = new Dispositivo("iphone3", "55422323", "xanxo3");
var dispositivo4 = new Dispositivo("iphone4", "55092723", "xanxo4");

pubsub.sub('mensaje', (function(data) {dispositivo1.recibirMensaje(data)}));
pubsub.sub('mensaje', (function(data) {dispositivo2.recibirMensaje(data)}));
pubsub.sub('mensaje', (function(data) {dispositivo3.recibirMensaje(data)}));
pubsub.sub('mensaje', (function(data) {dispositivo4.recibirMensaje(data)}));