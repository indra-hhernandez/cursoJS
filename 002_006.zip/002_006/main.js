/*1) Realiza la modelización de un parque natural. Empieza con el siguiente código.

var parqueNatural = {
areas = [],
parqueDeBomberos = {}
}

En cada una de las áreas (añade 10 áreas) encontraremos un array de árboles (100 por área) y un array de visitantes (100 en todo el parque).
En el parque de bomberos encontraremos un array de bomberos (10) y posiblemente más propiedades que se te puedan ocurrir.
Los bomberos y los visitantes deberán heredar de la clase Persona.

2) Añade un método ejecutar ciclo que represente el paso de 1h en el parque.
Cada ciclo que pase debemos llamar a ejecutar ciclo de los visitantes que se irán cambiando de area de forma aleatoria.
Haz que el método se ejecute cada segundo.

3) En cada paso de un ciclo se puede originar un fuego (probabilidad del 5%) que empezaría quemando un arbol aleatorio dentro del parque.
Cada ciclo que pase el fuego se extenderá al arbol al arbol siguiente, si no hay arbol siguiente, deberá saltar al primer arbol del área siguiente.
Asi sucesivamente hasta expandirse por todo el parque. Cada ciclo que pase el fuego en los arboles, estos estarán un 10% más quemados.
Cuando lleguen al 100% de quemados, se habrá perdido el arbol. (Quitarlo del área).​
*/

/*1) Añade un objeto viento​ (de clase viento), con el siguiente atributo:
Velocidad: Nula/Media/alta
En cada ejecución el viento tendrá una velocidad aleatoria
Si la velocidad es nula el incendio se expandirá 1 arbol, si la velocidad es media: dos árboles, si la dirección es alta: 3 árboles.
2) Los incendios ya no se originan de forma aleatoria en cualquier parte del bosque.
Los incendios los pueden originar los visitantes que sean fumadores (2 de cada 10). En cada ciclo hay una probabilidad del 10% de que un visitante fumador tire una colilla en el área en el que está y provoque un incendio.
*/

/*
1) Añade un sensor de fuego a uno de cada 15 árboles de forma aleatoria.
En caso de quemarse un árbol con sensor, deberá emitir una notificación al pubsub (mediante evento) 
El parque de bomberos escuchará las notificación y mandará a todos los bomberos al área
2) Cada ciclo que pase un bombero en un área con árboles encendidos, podrá apagar el fuego de 2 árboles.
Cuando se apaguen todos los árboles de un área los bomberos regresarán al parque.
3) Cada ciclo que pase un árbol apagado, pero con quemaduras, este se deberá recuperar un 10% cada ciclo.
4) Añade cierta lógica en el parque de bomberos de manera que si hay más de un fuego, 
los bomberos se dividan entre las áreas afectadas. Para ello el parque tendrá que llevar control
del número de incendios que hay. Para registrarlos lo hará mediante la notificación emitida por los 
sensores. Para saber cuándo se han apagado, recibirán una señal del área indicando que ya está todo apagado.
*/

//Definiendo Globales
var nombresPersona = ["Victor", "Omar", "Karen", "Ariel", "Omar", "David", "Esteban", "Matías", "Vlairner", "Lucy", "Ignacio", "Humberto", "Nestor", "Daniel", "Raymundo"];
var totalVisitantes = 100;
var avanceQuemado = 10;

function getRandomInteger(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generarNombreAleatorio() {
	var numeroAleatorio = Math.floor(Math.random() * nombresPersona.length);
	return nombresPersona[numeroAleatorio];
}

//Definiendo Parque
var ParqueNatural = function() {
	this._areas = [];
	this._parqueBomberos = new ParqueBomberos();

	for(var iArea=0; iArea<10; iArea++) {
		this._areas.push(new Area(iArea));
	}

	for(var iBombero=0; iBombero<10; iBombero++) {
		this._parqueBomberos._bomberos.push(new Bombero(iBombero));
	}
}

ParqueNatural.prototype.addVisitante = function() {
	var visitantes = 0;

	for(var iArea=0; iArea<this._areas.length; iArea++) {
		visitantes += this._areas[iArea]._visitantes.length;
	}

	if(visitantes < totalVisitantes) {
		var areaAleatoria = getRandomInteger(0, this._areas.length-1);
		this._areas[areaAleatoria]._visitantes.push(new Visitante());
	}
}

ParqueNatural.prototype.addVisitantes = function() {
	var cantidad = getRandomInteger(1, 20);
	
	for (var i=0; i<cantidad; i++) {
		this.addVisitante();
	}
}

ParqueNatural.prototype.ocurreIncendio = function() {
	var probabilidad = getRandomInteger(1, 20);
	var iarea = 0;
	var iarbol = 0;
	var incendio = false;
	var area = null;

	if(probabilidad == 1) {
		while(!incendio) {
			iarea = getRandomInteger(1, this._areas.length)-1;
			area = this._areas[iarea];
			if(this._areas[iarea]._arboles.length > 0) {
				iarbol = getRandomInteger(1, this._areas[iarea]._arboles.length)-1;
				console.log("Intentando incendio area " + iarea + " arbol " + iarbol);
				var arbol = this._areas[iarea]._arboles[iarbol];
				if(!arbol._incendiado) {
					arbol._incendiado = true;
					incendio = true;
					console.log("Nuevo incendio area " + iarea + " arbol " + iarbol);
				}
			}
		}
	}
}

ParqueNatural.prototype.avanceIncendio = function() {
	var totalApagados = 0;
	var totalIncendiados = 0;
	for(var iarea=0; iarea<this._areas.length; iarea++) {
		totalIncendiados = 0;
		var area = this._areas[iarea];
		for(var iarbol=this._areas[iarea]._arboles.length-1; iarbol>=0; iarbol--) {
			var arbol = this._areas[iarea]._arboles[iarbol];
			arbol.cicloArbol();

			if(arbol._incendiado) {
				totalIncendiados++;
				if(this._areas[iarea]._bomberos.length > 0) {
					if(totalApagados < 2) {
						arbol._incendiado = false;
						totalApagados++;
					}
				} else {
					if(arbol._sensor) {
						pubsub.pub('incendio', area);
						console.log("Detectando incendio " + iarea + " arbol " + iarbol);
					}
					if(iarbol == this._areas[iarea]._arboles.length-1) {
						if(iarea == this._areas.length-1) {
							if(this._areas[0]._arboles.length > 0) {
								this._areas[0]._arboles[0]._incendiado = true;
							}
						}
						else {
							if(this._areas[iarea+1]._arboles.length > 0) {
								this._areas[iarea+1]._arboles[0]._incendiado = true;
							}
						}
					} else {
						this._areas[iarea]._arboles[iarbol+1]._incendiado = true;
					}
				}
			}
		}
		if(totalIncendiados==0 && this._areas[iarea]._bomberos.length > 0) {
			this._parqueBomberos.recuperaBomberos(this._areas[iarea]);
		}
	}
}

ParqueNatural.prototype.eliminarQuemados = function() {
	for(var iarea=0; iarea<this._areas.length; iarea++) {
		for(var iarbol=0; iarbol<this._areas[iarea]._arboles.length; iarbol++) {
			var arbol = this._areas[iarea]._arboles[iarbol];
			
			if(arbol._quemado == 100) {
				this._areas[iarea]._arboles.splice(iarbol,1);
			}
		}
	}
}

ParqueNatural.prototype.cambioArea = function() {
	for(var iarea=0; iarea<this._areas.length; iarea++) {
		for(var ivisitante=0; ivisitante<this._areas[iarea]._visitantes.length; ivisitante++) {
			this._areas[iarea]._visitantes[ivisitante].cicloVisitante(this._areas[iarea]);
		}
	}
}

ParqueNatural.prototype.verTabla = function() {
	var tablaHTML = "<table>";

	for(var iarea=0; iarea<this._areas.length; iarea++) {
		tablaHTML += "<tr>";
		for(var v=0; v<this._areas[iarea]._visitantes.length; v++) {
			if(this._areas[iarea]._visitantes[v]._fumador) {
				tablaHTML += "<td><img src='img/fumador.png' height='10' width='10'></td>";
			} else{
				tablaHTML += "<td><img src='img/persona.jpg' height='10' width='10'></td>";
			}
		}
		for(var b=0; b<this._areas[iarea]._bomberos.length; b++) {
			tablaHTML += "<td><img src='img/bombero.JPG' height='10' width='10'></td>";
		}

		tablaHTML += "</tr>";
		tablaHTML += "<tr>";
		for(var iarbol=0; iarbol<this._areas[iarea]._arboles.length; iarbol++) {
			var arbol = this._areas[iarea]._arboles[iarbol];

			if(iarbol==50) {
				tablaHTML += "</tr><tr>";
			}
			
			tablaHTML += "<td id="+iarea+"_"+iarbol+">";
			if(arbol._incendiado) {
				if(arbol._quemado == 100) {
					tablaHTML += "<img src='img/quemado.JPG' height='10' width='10'";
				} else {
					tablaHTML += "<img src='img/ardiendo.JPG' height='10' width='10'";
				}
			} else {
				tablaHTML += "<img src='img/arbol.JPG' height='10' width='10'";
			}
			if(arbol._sensor) {
				tablaHTML += " border='1'>";	
			} else {
				tablaHTML += ">";
			}
			tablaHTML += "</td>";
		}
		tablaHTML += "</tr>";
	}
	tablaHTML += "</table>";

	document.getElementById('tablaHtml').innerHTML = tablaHTML;
}

ParqueNatural.prototype.fin = function() {
	var arboles = 0;
	
	for(var iArea=0; iArea<this._areas.length; iArea++) {
		arboles += this._areas[iArea]._arboles.length;
	}

	return (arboles == 0);
}

var Incendio = function(area) {
	this._area = area;
	this._apagado = false;
}

//Definiendo Viento
var Viento = function() {
	this.direccion = 0;
	this.velocidad = 0;
}

//Definiendo parque bomberos
var ParqueBomberos = function() {
	this._bomberos = [];
	this._incendios = [];
}

ParqueBomberos.prototype.enviaBomberos = function(area) {
	var bomberos = [];
	var totalIncendios = 0;

	this._incendios.push(new Incendio(area));

	//Se recuperan todos los bomberos en incendios
	for(var x=0; x<this._incendios.length; x++) {
		if(!this._incendios[x]._apagado) {
			totalIncendios++;
			var area = this._incendios[x]._area;
			for(var y=0; y<area._bomberos.length; y++) {
				bomberos.push(area._bomberos[y]);
			}
			area._bomberos = [];
		}
	}

	if(totalIncendios > 0) {
		//Se recuperan los bomberos en descanso
		for(var z=0; z<this._bomberos.length; z++) {
			bomberos.push(this._bomberos[z]);
		}
		this._bomberos = [];

		//Se distribuyen los bomberos entre los incendios
		while(bomberos.length>0) {
			for(var idx=0; idx<this._incendios.length; idx++) {
				if(!this._incendios[idx]._apagado) {
					this._incendios[idx]._area._bomberos.push(bomberos[bomberos.length-1]);
					bomberos.pop();
				}
			}
		}
	} else {
		for(var ind=0; ind<bomberos.length; ind++) {
			this._bomberos.push(bomberos[ind]);
		}	
	}

	bomberos = [];
}

ParqueBomberos.prototype.recuperaBomberos = function(area) {
	for(var i=0; i<area._bomberos.length; i++) {
		this._bomberos.push(area._bomberos[i]);
	}
	area._bomberos = [];

	//Confirmando apagado de incendio
	for(var x=0; x<this._incendios.length; x++) {
		if(this._incendios[x]._area._areaId == area._areaId) {
			this._incendios[x]._apagado = true;
		}
	}
}

//Definiendo Area
var Area = function(id) {
	this._areaId = id;
	this._arboles = [];
	this._visitantes = [];
	this._bomberos = [];

	for(var i=0; i<100; i++) {
		this._arboles.push(new Arbol(id));
	}
}

//Definiendo Arbol
var Arbol = function(idArea, idArbol) {
	this._areaId = idArea;
	this._incendiado = false;
	this._quemado = 0;
	this._sensor = (getRandomInteger(1, 15) == 1) ? true : false;
}

Arbol.prototype.cicloArbol = function() {
	if(this._incendiado) {
		if(this._quemado >= 100) {
			this._quemado = 100;
		} else {
			this._quemado += avanceQuemado;
		}
	} else {
		if(this._quemado > 0) {
			this._quemado -= avanceQuemado;
		}
	}
}

//Definiendo Persona
var Persona = function() {
	this._nombre = generarNombreAleatorio();
}

//Definiendo Bombero
var Bombero = function() {
}

Bombero.prototype = new Persona();

//Definiendo Visitante
var Visitante = function() {
	this._fumador = (getRandomInteger(1, 10) < 3) ? true : false;
}

//Definiendo Visitante
Visitante.prototype = new Persona();

Visitante.prototype.cicloVisitante = function(area) {
	var areaIndice = getRandomInteger(0, 9);
	var visitanteId = area._visitantes.indexOf(this);
	area._visitantes.splice(visitanteId, 1);
	parque._areas[areaIndice]._visitantes.push(this);
}

//Objeto pubsub
var pubsub = (function() {
	var suscriptores = {};

	function subscribe(event, callback) {
		if(!suscriptores[event]) {
			var suscriptorArray = [callback];
			suscriptores[event] = suscriptorArray;
		} else {
			suscriptores[event].push(callback);
		}
	}

	function publish(event, data) {
		if(suscriptores[event]) {
			suscriptores[event].forEach(function(callback) {
				callback(data);
			});
		}
	}
	return {
		pub: publish,
		sub: subscribe
	};
}());

parque = new ParqueNatural();
pubsub.sub('incendio', (function(data) {parque._parqueBomberos.enviaBomberos(data)}));

function cicloParque() {
	parque.addVisitantes();
	parque.cambioArea();
	parque.eliminarQuemados();
	parque.avanceIncendio();
	parque.ocurreIncendio();
	if(parque.fin()) {
		clearInterval(intervalID);
		console.log("Parque consumido");
	}
	parque.verTabla();
}

var intervalID = setInterval(cicloParque, 1000);