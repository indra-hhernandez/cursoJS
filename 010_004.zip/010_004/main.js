//Definición de globales
var nombresPersona = ["Victor", "Omar", "Karen", "Ariel", "Omar", "David", "Esteban", "Matías", "Vlairner", "Lucy", "Ignacio", "Humberto", "Nestor", "Daniel", "Raymundo"];
var cargosCamarero = ["Encargado", "Mozo"];

var nombreComida = ["Recado Negro", "Durango en Pulque", "Del campo", "Mediterranea", "MedMex"];
var nombreEntrante = ["Arrenque a la Crema", "Cazuela de tuetano", "Carnitas de Pato", "Camarones y setas al ajillo", "Quesadillas lacandonas"];
var nombrePrincipal = ["Fetuccini Alfredo", "Ravioles rellenos", "Pastrami Kosher", "Filete de róbalo", "Pierna de ternera"];
var nombrePostre = ["Creme Brulee", "Tarta de Almendras", "Profiteroles", "Sorbete de Mango", "Cheese Cake de Guayaba"];
var nombreBebida = ["Cisne Negro", "Via del campo", "Cucaracha", "Martini", "Flirtini"];

var titulosBebidas = ["Nombre", "Grado de Alcohol", "Precio"];
var titulosComidas = ["Nombre", "Tiempos", "Precio"];

const NUMCOMIDAS = 5;
const NUMMESAS = 30;
const NUMCAMAREROS = 5;

function getRandomInteger(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generarDatoAleatorio(opciones) {
	var numeroAleatorio = Math.floor(Math.random() * opciones.length);
	return opciones[numeroAleatorio];
}

creaContenedorByClass = function(claseContenedor, contenido, clase) {
	let sHtml = "class='" + clase + "'>" + contenido;
	let contenedor = document.querySelector(claseContenedor)
	creaContenedor(sHtml, contenedor);
}

creaContenedorById = function(idContenedor, contenido, clase) {
	let sHtml = "class='" + clase + "'>" + contenido;
	let contenedor = document.getElementById(idContenedor);
	creaContenedor(sHtml, contenedor);
}

creaContenedor = function(sHtml, contenedor) {
	let elemento = document.createElement("DIV");
	elemento.innerHTML = "<div " + sHtml + "</div>";
	contenedor.appendChild(elemento);
}

creaBoton = function(id, stexto, claseContenedor, clase) {
	let elemento = document.createElement("BUTTON");
	let texto = document.createTextNode(stexto);
	let contenedor = document.querySelector(claseContenedor);
	elemento.appendChild(texto);
	elemento.id = id;
	elemento.className = clase;
	contenedor.appendChild(elemento);
}

//Definición de Persona
class Persona {
	constructor() {
		this._nombre = generarDatoAleatorio(nombresPersona);
		this._edad = getRandomInteger(20, 60);
	}
}

//Definición de Cliente
class Cliente extends Persona {
	constructor() {
		super();
		this._dinero = getRandomInteger(0, 1500);
		this._enfado = 0;
	}

	generaOrden(carta) {
		let idComida = getRandomInteger(0, carta._comidas.length-1);
		let idBebida = getRandomInteger(0, carta._bebidas.length-1);
		return new Orden(carta._comidas[idComida], carta._bebidas[idComida]);
	}
}

//Definición de Camarero
class Camarero extends Persona {
	constructor() {
		super();
		this._cargo = generarDatoAleatorio(cargosCamarero);
	}

	pintar() {
		let contenido = this._nombre;
		let clase = "mesero mesero" + (this._cargo == "Mozo" ? "_m" : "_e");
		creaContenedorByClass(".meseros", contenido, clase);
	}
}

//Definición de Mesa
class Mesa {
	constructor(id) {
		this._mesaId = id;
		this._capacidad = getRandomInteger(2, 10);
		this._ocupada = false;
		this._clientes = [];
		this._ordenes = [];
		this._carta = false;
	}

	pintar() {
		let contenido = this._mesaId + "<br/>" + this._clientes.length + "/" + this._capacidad + "<br/>" + (this._carta ? "*" : "") + this._ordenes.length;
		let clase = "mesa mesa" + (this._ocupada ? "_o" : "_d");
		creaContenedorByClass(".mesas", contenido, clase);
	}

	recibirClientes(grupo) {
		this._clientes = this._clientes.concat(grupo);
		this._ocupada = true;
	}

	asignaCarta() {
		if(this._clientes.length > 0 && !this._carta) {
			this._carta = true;
		}
	}

	generaOrdenes(carta) {
		for(let i=0; i<this._clientes.length; i++) {
			this._ordenes.push(this._clientes[i].generaOrden(carta));
		}
	}
}

//Definiendo Orden
class Orden {
	constructor(comida, bebida) {
		this._comida = comida;
		this._bebida = bebida;
	}
}

//Definición de Producto
class Producto {
	constructor(nombre) {
		this._nombre = nombre;
		this._existencias = getRandomInteger(2, 20);
		this._calorias = getRandomInteger(100, 500);
		this._precio = getRandomInteger(30, 200);
	}
}

//Definición de Comida
class Comida extends Producto {
	constructor(nombre, entrante, principal, postre) {
		super(nombre);
		this._entrante = generarDatoAleatorio(nombreEntrante);
		this._principal = generarDatoAleatorio(nombrePrincipal);
		this._postre = generarDatoAleatorio(nombrePostre);
	}

	toHTML() {
		return "<tr><td>" + this._nombre + "</td><td>" + this._entrante + "/" + this._principal + "/" + this._postre + "</td><td>" + this._precio + "</td></tr>";
	}
}

//Definición de Bebida
class Bebida extends Producto {
	constructor(nombre) {
		super(nombre);
		this._esAlcoholica = (getRandomInteger(1, 2) == 1) ? true : false;
		this._gradoAlcohol = getRandomInteger(3, 20);
	}

	toHTML() {
		return "<tr><td>" + this._nombre + "</td><td>" + (this._esAlcoholica ? this._gradoAlcohol : 0) + "</td><td>" + this._precio + "</td></tr>";
	}
}

//Definición de Carta
class Carta {
	constructor() {
		this._comidas = [];
		this._bebidas = [];

		this.generaComidasAleatorias();
		this.generaBebidasAleatorias();

	}

	generaComidasAleatorias() {
		for(let i=0; i<NUMCOMIDAS; i++){
			this._comidas.push(new Comida(generarDatoAleatorio(nombreComida)));
		}	
	}

	generaBebidasAleatorias() {
		for(let i=0; i<NUMCOMIDAS; i++){
			this._bebidas.push(new Bebida(generarDatoAleatorio(nombreBebida)));
		}	
	}

	pintar(){
		let sHtml = "";

		sHtml += "<h2>Nuestra carta:</h2>";
		sHtml += this.getTablaHTML("Bebidas", titulosBebidas, this._bebidas);
		sHtml += this.getTablaHTML("Comidas", titulosComidas, this._comidas);

		document.querySelector(".carta").innerHTML = sHtml;
	}

	getTablaHTML(titulo, titulos, datos) {
		let sHtml = "";

		sHtml += "<h3>" + titulo + ":</h3>";
		sHtml += "<table>";
		sHtml += "<thead><tr>" + this.getTitulosHTML(titulos) + "</tr></thead>";
		sHtml += "<tbody>";
		sHtml += "<tbody><tr>" + this.getDatosHTML(datos) + "</tr></tbody>";
		sHtml += "</table>";

		return sHtml;
	}

	getTitulosHTML(titulos) {
		let sHtml = "";

		for(let i=0; i<titulos.length; i++){
			sHtml += "<td>" + titulos[i] + "</td>"
		}

		return sHtml;
	}

	getDatosHTML(datos) {
		let sHtml = "";

		for(let i=0; i<datos.length; i++){
			sHtml += "<td>" + datos[i].toHTML() + "</td>"
		}

		return sHtml;
	}
}

//Definición de Recepcion
class Recepcion {
	constructor() {
		this._gruposPersonas = [];
	}

	addGrupoPersonas(){
		let grupo = new GrupoPersonas();
		grupo.generaGrupoClientesAleatorio();
		this._gruposPersonas.push(grupo);
	}

	pintar() {
		this._gruposPersonas.forEach( (grupo) => grupo.pintar());
	}

	getPrimerGrupo() {
		let grupo;
		
		if(this._gruposPersonas.length > 0) {
			grupo = this._gruposPersonas[0]._clientes;
		}

		return grupo;
	}

	removePrimerGrupo() {
		this._gruposPersonas.shift();
	}
}

//Definición de Recepcion
class GrupoPersonas {
	constructor() {
		this._clientes = [];
	}

	generaGrupoClientesAleatorio() {
		let total = getRandomInteger(2, 20);
		for(let i=0; i<total; i++) {
			this._clientes.push(new Cliente());
		}
	}

	pintar() {
		let clase = "grupopersonas";
		let contenido = this._clientes.length
		creaContenedorByClass(".recepcion", contenido, clase);
	}
}

//Definición de Restaurante
class Restaurante {
	constructor(nombre) {
		this._nombre = nombre;
		this._mesas = [];
		this._camareros = [];
		this._carta = new Carta();
		this._recepcion = new Recepcion();
		this._contadorMesas = 0;

		this._id = this.generarIdAleatorio();
		this.generaMesasAleatorio();
		this.generarCamarerosAleatorio()
		this.pintarEstructuraPrincipalConBotones();
	}

	generarIdAleatorio() {
		return "restTest" + getRandomInteger(1, 99);
	}

	generaMesasAleatorio() {
		for(let i=0; i<NUMMESAS; i++) {
			this._mesas.push(new Mesa(++this._contadorMesas));
		}		
	}

	generarCamarerosAleatorio() {
		for(let i=0; i<NUMCAMAREROS; i++) {
			this._camareros.push(new Camarero());
		}
	}

	pintarEstructuraPrincipalConBotones() {
		//Creando contenedor principal
		let elemento = document.createElement("DIV");
		elemento.innerHTML = "<div id='" + this._id + "'></div>";
		document.body.appendChild(elemento);

		//Creando contenedores de la aplicación
		creaContenedorById(this._id, "", "botones");
		creaContenedorById(this._id, "", "carta");
		creaContenedorById(this._id, "", "mapa");
		creaContenedorByClass(".mapa", "", "mesas");
		creaContenedorByClass(".mapa", "", "meseros");
		creaContenedorById(this._id, "", "recepcion");

		this.pintarBotones();
		this._carta.pintar();
	}

	iniciarIntervalo() {
		window.setInterval( () => this.ejecutarCiclo(), 2000);
	}

	ejecutarCiclo() {
		this.pintar();
	}

	pintar() {
		this.limpiar();
		this._mesas.forEach( (mesa) => mesa.pintar());
		this._camareros.forEach( (camarero) => camarero.pintar());
		this._recepcion.pintar();
	}

	limpiar() {
		document.querySelector(".mesas").innerHTML = "";
		document.querySelector(".meseros").innerHTML = "";
		document.querySelector(".recepcion").innerHTML = "";
	}

	asignarMesas() {
		let grupo = this._recepcion.getPrimerGrupo();

		if(grupo) {
			let mesa = this.obtenerMesaDisponible(grupo.length);

			if(mesa) {
				mesa.recibirClientes(grupo);
			} else {
				alert("No es posible asignar mesa, grupo se va!");
			}
				
			this._recepcion.removePrimerGrupo();
		}
	}

	obtenerMesaDisponible(total) {
		let mesa;

		for(let i=0; i<this._mesas.length; i++) {
			if(!mesa && !this._mesas[i]._ocupada && this._mesas[i]._capacidad >= total) {
				mesa = this._mesas[i];
			}
		}

		return mesa;
	}

	generaOrdenes() {
		this._mesas.forEach( (mesa) => mesa.asignaCarta());
		this._mesas.forEach( (mesa) => mesa.generaOrdenes(this._carta));
	}

	pintarBotones() {
		creaBoton("btnAddCtes", "Traer Clientes", ".botones", "button-main");
		document.getElementById("btnAddCtes").addEventListener("click", () => this._recepcion.addGrupoPersonas());
		creaBoton("btnRecCtes", "Recibir Clientes", ".botones", "button-main");
		document.getElementById("btnRecCtes").addEventListener("click", () => this.asignarMesas());
		creaBoton("btnTomaNota", "Tomar Nota", ".botones", "button-main");
		document.getElementById("btnTomaNota").addEventListener("click", () => this.generaOrdenes());
	}
}

//Iniciando Restaurante
window.onload = () => {
	let miRestaurante = new Restaurante("¡Comes y Te Vas!");
	miRestaurante.iniciarIntervalo();
}