var buscarParejas = function(array) {
	var suma = 0;
	var res = [];
	
	for(var i=0; i<array.length; i++) {
		for(var j=i; j<array.length; j++) {
			suma = array[i] + array[j];
			if(suma===0) {
				res.push(i + ',' + j);
			}
		}
	}

	return res;
}

var miArray = [2, -5, 10, 5, 4, -10, 0, -5];
console.log(buscarParejas(miArray));