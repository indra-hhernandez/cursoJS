var titulos = ["Nombre", "Ocupacion", "Arma", "Deuda", "ID"];

class Formulario {
	constructor() {

	}

	creaContenedorByClass(claseContenedor, contenido, clase) {
		let sHtml = "class='" + clase + "'>" + contenido;
		let contenedor = document.querySelector(claseContenedor)
		this.creaContenedor(sHtml, contenedor);
	}

	creaContenedorById(idContenedor, contenido, clase) {
		let sHtml = "class='" + clase + "'>" + contenido;
		let contenedor = document.getElementById(idContenedor);

		this.creaContenedor(sHtml, contenedor);
	}

	creaContenedor(sHtml, contenedor) {
		let elemento = document.createElement("DIV");

		elemento.innerHTML = "<div " + sHtml + "</div>";
		contenedor.appendChild(elemento);
	}

	creaBoton(id, stexto, claseContenedor, clase) {
		let elemento = document.createElement("BUTTON");
		let texto = document.createTextNode(stexto);
		let contenedor = document.querySelector(claseContenedor);

		elemento.appendChild(texto);
		elemento.id = id;
		elemento.className = clase;
		contenedor.appendChild(elemento);
	}

	creaInput(id, claseContenedor, clase, texto) {
		let elemento = document.createElement('INPUT');
		let contenedor = document.querySelector(claseContenedor);

		elemento.id = id;
		elemento.className = clase;
		elemento.placeholder = texto;
		contenedor.appendChild(elemento);
	}

	creaHidden(id, claseContenedor) {
		let elemento = document.createElement('INPUT');
		let contenedor = document.querySelector(claseContenedor);

		elemento.id = id;
		elemento.setAttribute("type", "hidden");
		contenedor.appendChild(elemento);
	}

	creaSelect(id, opciones, claseContenedor, clase) {
		let elemento = document.createElement('SELECT');
		let contenedor = document.querySelector(claseContenedor);
		
		elemento.id = id;
		elemento.className = clase;

		for(var i=0; i<opciones.length; i++) {
			var opcion = document.createElement('option');
			opcion.text = opciones[i];
			opcion.value = opciones[i];
			elemento.appendChild(opcion);
		}
		
		contenedor.appendChild(elemento);
	}

	obtenValorByID(nombre) {
		var elemento = document.getElementById(nombre);
		return elemento.value;
	}

	ponValorByID(nombre, texto) {
		var elemento = document.getElementById(nombre);
		elemento.value = texto;
	}
}

class ClienteAPI {
	constructor() {
	}

	get(url, callback) {
		let xhr = new XMLHttpRequest();
		xhr.open("GET", url);

		xhr.onreadystatechange = function(response) {
			if (xhr.readyState == 4) {
				let respuesta = JSON.parse(xhr.responseText);
				callback(respuesta);
			}
		}

		xhr.send();
	}

	post(url, params, callback) {
		let xhr = new XMLHttpRequest();
		let data = new FormData();

		for(let prop in params) {
			data.append(prop, params[prop]);
		}

		xhr.open("POST", url);

		xhr.onreadystatechange = function(response) {
			if (xhr.readyState == 4) {
				let respuesta = JSON.parse(xhr.responseText);
				callback(respuesta);
			}
		}

		xhr.send(data);
	}

	del(url, callback) {
		let xhr = new XMLHttpRequest();

		xhr.open("DELETE", url);

		xhr.onreadystatechange = function(response) {
			if (xhr.readyState == 4) {
				callback(xhr.responseText);
			}
		}

		xhr.send();
	}

	put(url, params, callback) {
		let xhr = new XMLHttpRequest();
		let data = new FormData();

		for(let prop in params) {
			data.append(prop, params[prop]);
		}

		xhr.open("PUT", url);

		xhr.onreadystatechange = function(response) {
			if (xhr.readyState == 4) {
				let respuesta = JSON.parse(xhr.responseText);
				callback(respuesta);
			}
		}

		xhr.send(data);
	}
}

class ClienteApiPersonajes {
	constructor() {
		this._urlBase = "https://ironhack-characters.herokuapp.com";
		this._clienteAPI = new ClienteAPI();
	}

	getDePersonajes(callback) {
		let urlCompleta = this._urlBase + "/characters";
		let callbackPersonajes = (respuesta) => {
			let arrayPersonajes = [];

			for(let i=0; i<respuesta.length; i++) {
				let elem = respuesta[i];
				let personaje = new Personaje(elem.name, elem.occupation, elem.debt, elem.weapon, elem.id);
				arrayPersonajes.push(personaje);
			}

			callback(arrayPersonajes);
		}
		
		this._clienteAPI.get(urlCompleta, callbackPersonajes);
	}

	postDePersonajes(personaje, callback) {
		let urlCompleta = this._urlBase + "/characters";
		let callbackPersonaje = (respuesta) => {
			let personaje = new Personaje(respuesta.name, respuesta.occupation, respuesta.debt, respuesta.weapon);
			callback(personaje);
		}

		let params = {
			name: personaje._nombre,
			occupation: personaje._ocupacion,
			debt: personaje._deuda,
			weapon: personaje._arma,
		}

		this._clienteAPI.post(urlCompleta, params, callbackPersonaje);
	}

	deleteDePersonajes(id, callback) {
		let urlCompleta = this._urlBase + "/characters/" + id;
		let callbackPersonaje = (respuesta) => {
			callback(respuesta);
		}
		this._clienteAPI.del(urlCompleta, callbackPersonaje);
	}

	putDePersonajes(personaje, callback) {
		let urlCompleta = this._urlBase + "/characters/" + personaje._id;
		let callbackPersonaje = (respuesta) => {
			let personaje = new Personaje(respuesta.name, respuesta.occupation, respuesta.debt, respuesta.weapon);
			callback(personaje);
		}

		let params = {
			name: personaje._nombre,
			occupation: personaje._ocupacion,
			debt: personaje._deuda,
			weapon: personaje._arma,
		}

		this._clienteAPI.put(urlCompleta, params, callbackPersonaje);
	}
}

class Personaje {
	constructor(nombre, ocupacion, deuda, arma, id) {
		this._nombre = nombre;
		this._ocupacion = ocupacion;
		this._deuda = deuda;
		this._arma = arma;
		this._id = id;
	}

	pintar() {
		return "<tr><td><a href='javascript:almacen.editPersonaje(\"" + this._id + "\",\"" + this._nombre + "\",\"" + this._ocupacion + "\",\"" + this._arma + "\",\"" + this._deuda + "\")'>" + this._nombre + "</a></td><td>" + this._ocupacion + "</td><td>" + this._arma + "</td><td>" + this._deuda + "</td><td>" + this._id + "</td></tr>";
	}
}

class AlmacenPersonajes {
	constructor() {
		this._id = "Almacen";
		this._personajes = [];
		this._clienteAPIPersonajes = new ClienteApiPersonajes();
	}

	addPersonaje() {
		let formulario = new Formulario();
		let personaje = new Personaje("", "", "", "");

		personaje._nombre = formulario.obtenValorByID("txtNombre");
		personaje._ocupacion = formulario.obtenValorByID("txtOcupacion");
		personaje._arma = formulario.obtenValorByID("txtArma");
		personaje._deuda = (formulario.obtenValorByID("selDeuda") == "No" ? "false" : "true");

		let callback = (data) => {
    		if(typeof(data) == "object") {
    			this.pintarPersonajes();
    		}
    	}

		this._clienteAPIPersonajes.postDePersonajes(personaje, callback);
	}

	deletePersonaje() {
		let formulario = new Formulario();
		let id = formulario.obtenValorByID("txtID");
		let callback = (data) => {
			console.log(data);
    		this.pintarPersonajes();
    	}

		this._clienteAPIPersonajes.deleteDePersonajes(id, callback);
	}

	editPersonaje(id, nombre, ocupacion, arma, deuda) {
		let formulario = new Formulario();

		formulario.ponValorByID("txtNombre", nombre);
		formulario.ponValorByID("txtOcupacion", ocupacion);
		formulario.ponValorByID("txtArma", arma);
		formulario.ponValorByID("selDeuda", deuda);
		formulario.ponValorByID("txtID", id);
	}

	putPersonaje() {
		let formulario = new Formulario();
		let personaje = new Personaje("", "", "", "");

		personaje._nombre = formulario.obtenValorByID("txtNombre");
		personaje._ocupacion = formulario.obtenValorByID("txtOcupacion");
		personaje._arma = formulario.obtenValorByID("txtArma");
		personaje._deuda = (formulario.obtenValorByID("selDeuda") == "No" ? "false" : "true");
		personaje._id = formulario.obtenValorByID("txtID");

		let callback = (data) => {
    		if(typeof(data) == "object") {
    			this.pintarPersonajes();
    		}
    	}

		this._clienteAPIPersonajes.putDePersonajes(personaje, callback);
	}

	pintarPersonajes(){
    	let callback = (data) => {
    		document.querySelector(".lista").innerHTML = this.getTabla(data);
    	}

    	this._clienteAPIPersonajes.getDePersonajes(callback);
    }

    getTabla(data) {
		let sHtml = "";

		sHtml += "<table>";
		sHtml += "<thead>" + this.getTitulos() + "</thead>";
		sHtml += "<tbody>";
		sHtml += "<tbody>" + this.getDatosHTML(data) + "</tbody>";
		sHtml += "</table>";

		return sHtml;
	}

	getTitulos() {
		let sHtml = "<tr>";

		for(let i=0; i<titulos.length; i++){
			sHtml += "<td>" + titulos[i] + "</td>"
		}

		return sHtml + "</tr>";
	}

	getDatosHTML(datos) {
		let sHtml = "";

		for(let i=0; i<datos.length; i++){
			let personaje = datos[i];
			sHtml += personaje.pintar();
		}

		return sHtml;
	}

    pintarEstructuraConBotones() {
    	let formulario = new Formulario();
		//Creando contenedor principal
		let elemento = document.createElement("DIV");
		elemento.innerHTML = "<div id='" + this._id + "'></div>";
		document.body.appendChild(elemento);

		//Creando contenedores de la aplicación
		formulario.creaContenedorById(this._id, "", "botones");
		formulario.creaContenedorById(this._id, "", "lista");

		this.pintarBotones();
	}

	pintarBotones() {
		let formulario = new Formulario();
		let sHtml = "";

		sHtml += "<h3>Añadir Personaje</h3>";

		document.querySelector(".botones").innerHTML = sHtml;
		
		formulario.creaInput("txtNombre", ".botones", "input", "Nombre");
		formulario.creaInput("txtOcupacion", ".botones", "input", "Ocupación");
		formulario.creaInput("txtArma", ".botones", "input", "Arma");
		formulario.creaSelect("selDeuda", ["Sí", "No"], ".botones", "input");
		formulario.creaHidden("txtID", ".botones");

		formulario.creaBoton("btnAddPersonaje", "Crear", ".botones", "button-main");
		document.getElementById("btnAddPersonaje").addEventListener("click", () => this.addPersonaje());
		formulario.creaBoton("btnDelPersonaje", "Borrar", ".botones", "button-main");
		document.getElementById("btnDelPersonaje").addEventListener("click", () => this.deletePersonaje());
		formulario.creaBoton("btnUpdPersonaje", "Editar", ".botones", "button-main");
		document.getElementById("btnUpdPersonaje").addEventListener("click", () => this.putPersonaje());
	}
}

let almacen;

window.onload = () => {
	almacen = new AlmacenPersonajes();
	almacen.pintarEstructuraConBotones();
	almacen.pintarPersonajes();
}