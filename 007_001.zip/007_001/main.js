/*
1) Modela la clase Vehículo, con las siguientes propiedades:
    Marca (aleatorio)
    Modelo (aleatorio)
    VelocidadMaxima (aleatorio entre 100kmh y 200kmh)
Realiza la clase Motocicleta y Coche que hereden de vehículo

2) Realiza la clase carrera que recibirá dos vehículos en su consctrucción. La clase carrera tendrá el método iniciarCarrera() que hará que los dos vehículos compitan.
Una carrera consistirá en ver qué vehículo recorre primero 200 metros. Para ser realista deberás hacer que los vehículos avancen cada segundo los metros correspondientes.
Ganará el que recorra antes los 200 metros. En caso de llegar a la vez, quedarán empatados e irán a penales. 
Naaaaaaaaah, no hay penales. Pero sí que pueden empatar.

3) Pinta en tu html la carrera. Haz uso de funciones de manejo del DOM, y haz uso de CSS para modificar su posición.
*/

//Definiendo Globales
var velocidadMinima = 100;
var velocidadMaxima = 200;
var tiempoRefresco = 100;

var marca = ["Nissan", "Audi", "Chevrolet"];
var submarca = ["GRT", "XM1", "DF3"];
var color = ["Negro", "Verde", "Azul", "Amarillo"];
var auto = ["vehiculo1.png", "vehiculo2.png", "vehiculo3.png", "vehiculo4.png", "vehiculo5.png", "vehiculo6.png"];
var moto = ["vehiculo7.png", "vehiculo8.png", "vehiculo9.png", "vehiculo10.png"];

function generarDatoAleatorio(arreglo) {
	var numeroAleatorio = Math.floor(Math.random() * arreglo.length);
	return arreglo[numeroAleatorio];
}

function getRandomInteger(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function avance(velocidad, tiempo) {
	return (velocidad / 3600) * tiempoRefresco;
}

//Definiendo Vehiculo
var Vehiculo = function() {
	this._velocidad = 0;
	this._marca = generarDatoAleatorio(marca);
	this._submarca = generarDatoAleatorio(submarca);
	this._modelo = getRandomInteger(2012, 2018);
	this._color = generarDatoAleatorio(color);
}

//Definiendo Automovil
var Automovil = function() {
	this._imagen = generarDatoAleatorio(auto);
	this._velocidad = getRandomInteger(velocidadMinima, velocidadMaxima)
}

Automovil.prototype = new Vehiculo();

//Definiendo Motocicleta
var Motocicleta = function() {
	this._imagen = generarDatoAleatorio(moto);
	this._velocidad = getRandomInteger(velocidadMinima, velocidadMaxima)
}

Motocicleta.prototype = new Vehiculo();

//Definiendo Carrera
var Carrera = function() {
	this._participante1 = getRandomInteger(1,2) == 1 ? new Automovil() : new Motocicleta();
	this._participante2 = getRandomInteger(1,2) == 1 ? new Automovil() : new Motocicleta();
	this._posicion1 = 0;
	this._posicion2 = 0;
	this._longitud = 200;
}

Carrera.prototype.iniciarCarrera = function() {
	this._intervalID = setInterval(avanceCarrera, tiempoRefresco);

	creaImagen("posicion1", "img/" + this._participante1._imagen);
	creaImagen("posicion2", "img/" + this._participante2._imagen);
}

Carrera.prototype.verCarrera = function() {
	var datosHtml = "";

	document.getElementById("posicion1").style.left = (this._posicion1 * 5) + "px";
	document.getElementById("posicion2").style.left = (this._posicion2 * 5) + "px";

	datosHtml += "<p>Velocidad Participante 1: " + this._participante1._velocidad + " km/h</p>";
	datosHtml += "<p>Velocidad Participante 2: " + this._participante2._velocidad + " km/h</p>";
	datosHtml += "<p>Avance Participante 1: " + this._posicion1 + " m</p>";
	datosHtml += "<p>Avance Participante 2: " + this._posicion2 + " m</p>";
	datosHtml += "<p>Ganador: PARTICIPANTE" +  ((carrera._posicion1 > carrera._posicion2) ? "1" : "2") + "</p>";

	document.getElementById("estadisticas").innerHTML = datosHtml;
}

function avanceCarrera() {
	carrera._posicion1 += avance(carrera._participante1._velocidad, tiempoRefresco);
	carrera._posicion2 += avance(carrera._participante2._velocidad, tiempoRefresco);

	if(carrera._posicion1 >= carrera._longitud || carrera._posicion2 >= carrera._longitud) {
		clearInterval(carrera._intervalID);
	}

	carrera.verCarrera();
}

function creaImagen(div, src) {
   var imagen = document.createElement("img"); 
   var objdiv = document.getElementById(div);
   
   imagen.setAttribute("src", src); 
   imagen.width = 100;
   imagen.height = 31;
   objdiv.appendChild(imagen); 
}

var carrera = new Carrera();

window.onload = function() {
	carrera.iniciarCarrera();
}



