/*
Realiza un formulario para recoger los datos de un coche. Añade al formulario un botón añadir que creará un nuevo coche a partir de los datos del formulario y lo añadirá a nuestro objeto carrera.

El formulario tendrá:
3 selects: Marca, Modelo, Imagen. 
1 input: VelocidadMaxima
2 Botones: AñadirVehículo e IniciarCarrera

Haz que se puedan añadir tantos vehículos como se deseen (no solo dos).
*/

//Definiendo Globales
var velocidadMinima = 100;
var velocidadMaxima = 200;
var tiempoRefresco = 100;

var marca = ["Seleccione Marca", "Nissan", "Audi", "Chevrolet"];
var submarca = ["Seleccione Modelo", "GRT", "XM1", "DF3"];
var color = ["Negro", "Verde", "Azul", "Amarillo"];
var auto = ["Seleccione Imagen", "vehiculo1.png", "vehiculo2.png", "vehiculo3.png", "vehiculo4.png", "vehiculo5.png", "vehiculo6.png"];

function generarDatoAleatorio(arreglo) {
	var numeroAleatorio = Math.floor(Math.random() * arreglo.length);
	return arreglo[numeroAleatorio];
}

function getRandomInteger(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function avance(velocidad, tiempo) {
	return (velocidad / 3600) * tiempoRefresco;
}

//Definiendo Vehiculo
var Vehiculo = function() {
	this._velocidad = 0;
	this._marca = "";
	this._submarca = "";
}

//Definiendo Automovil
var Automovil = function() {
	this._imagen = "";
}

Automovil.prototype = new Vehiculo();

Automovil.prototype.initAuto = function(marca, modelo, imagen, velocidad) {
	this._velocidad = getRandomInteger(velocidad-100, velocidad);
	this._marca = marca;
	this._submarca = modelo;
	this._imagen = imagen;
}

//Definiendo participante
var Participante = function() {
	this._automovil = new Automovil();
	this._posicion = 0;
}

//Definiendo Carrera
var Carrera = function() {
	this._participantes = [];
	this._longitud = 200;
}

Carrera.prototype.iniciarCarrera = function() {
	this._intervalID = setInterval(avanceCarrera, tiempoRefresco);

	for(var i=0; i<this._participantes.length; i++) {
		this._participantes[i]._posicion = 0;
	}
}

Carrera.prototype.avanceCarrera = function() {
	var maxAvance = 0;

	for(var i=0; i<this._participantes.length; i++) {
		this._participantes[i]._posicion += avance(this._participantes[i]._automovil._velocidad, tiempoRefresco);	
		maxAvance = (this._participantes[i]._posicion > maxAvance) ? this._participantes[i]._posicion : maxAvance;
	}

	if(maxAvance >= this._longitud) {
		clearInterval(this._intervalID);
	}

	this.verCarrera();
}

Carrera.prototype.verCarrera = function() {
	var datosHtml = "";

	for(var i=0; i<this._participantes.length; i++) {
		var indice = (i+1);
		document.getElementById("participante" + indice).style.left = (this._participantes[i]._posicion * 5) + "px";

		datosHtml += "<p>Velocidad: " + this._participantes[i]._automovil._velocidad + " km/h, ";
		datosHtml += "Avance: " + Math.round(this._participantes[i]._posicion) + " m</p>";
	}

	document.getElementById("estadisticas").innerHTML = datosHtml;
}

//Definiendo controles para objetos HTML
var Controlador = function() {
	this._controles = [];
}

Controlador.prototype.creaImage = function(div, src) {
   var imagen = document.createElement("img"); 
   var objdiv = document.getElementById(div);

   imagen.setAttribute("src", src); 
   imagen.width = 100;
   imagen.height = 31;
   objdiv.appendChild(imagen); 
}

Controlador.prototype.creaContenedor = function(div) {
   var contenedor = document.createElement("DIV"); 
   var objPista = document.getElementById("pista");
   
   contenedor.id = div;
   contenedor.className = "posicion";
   objPista.appendChild(contenedor);
}

Controlador.prototype.creaSelect = function(div, nombre, opciones, opcionCero) {
	var elemento = document.createElement('SELECT');
	var contenedor = document.getElementById(div);
	
	elemento.name = nombre;
	elemento.id = nombre;

	for(var i=0; i<opciones.length; i++) {
		var opcion = document.createElement('option');
		opcion.text = opciones[i];
		opcion.value = opciones[i];
		elemento.appendChild(opcion);
	}
	
	contenedor.appendChild(elemento);
}

Controlador.prototype.creaBoton = function(div, nombre, descripcion) {
	var elemento = document.createElement('BUTTON');
	var contenedor = document.getElementById(div);
	var texto = document.createTextNode(descripcion);

	elemento.name = nombre;
	elemento.id = nombre;
	elemento.appendChild(texto);
	contenedor.appendChild(elemento);
}

Controlador.prototype.creaInput = function(div, nombre) {
	var elemento = document.createElement('INPUT');
	var contenedor = document.getElementById(div);

	elemento.name = nombre;
	elemento.id = nombre;
	contenedor.appendChild(elemento);
}

Controlador.prototype.creaParticipante = function(indiceParticipante, auto) {
	var idParticipante = "participante" + indiceParticipante; 
	this.creaContenedor(idParticipante);
	this.creaImage(idParticipante, "img/" + auto._imagen);

	document.getElementById(idParticipante).style.top = ((indiceParticipante-1)*42) + "px";
	document.getElementById("pista").style.height = (Math.floor((indiceParticipante+1)/2) * 84) + "px";
}

Controlador.prototype.obtenValor = function(nombre) {
	var elemento = document.getElementById(nombre);
	return elemento.value;
}

var carrera = new Carrera();
var control = new Controlador();

window.onload = function() {
	control.creaSelect("controles", "selMarca", marca);
	control.creaSelect("controles", "selModelo", submarca);
	control.creaSelect("controles", "selImagen", auto);
	control.creaInput("controles", "txtVelocidad");
	control.creaBoton("controles", "btnAddVehiculo", "Añadir Vehículo");
	control.creaBoton("controles", "btnIniciarCarrera", "Iniciar Carrera");

	document.getElementById("btnAddVehiculo").addEventListener("click", addVehiculo);
	document.getElementById("btnIniciarCarrera").addEventListener("click", iniciarCarrera);

	console.log(document.getElementsByName("btnAddVehiculo"));
	console.log(document.getElementsByName("btnIniciarCarrera"));
}

function addVehiculo() {
	if(control.obtenValor("selImagen") == "" || control.obtenValor("txtVelocidad") == 0) {
		alert("Datos incorrectos");
	} else {
		var auto = new Automovil(document.getElementsByName("selMarca"))
		var participante = new Participante();
		auto.initAuto(control.obtenValor("selMarca"), control.obtenValor("selModelo"), control.obtenValor("selImagen"), control.obtenValor("txtVelocidad"));
		participante._automovil = auto;
		carrera._participantes.push(participante);
		control.creaParticipante(carrera._participantes.length, auto);
	}
}

function iniciarCarrera() {
	carrera.iniciarCarrera();
}

function avanceCarrera() {
	carrera.avanceCarrera();
}