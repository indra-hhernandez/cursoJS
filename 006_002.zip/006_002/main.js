var titulos = ["Nombre", "Ocupacion", "Arma", "Deuda", "ID"];

class Formulario {
	constructor() {

	}

	creaContenedorByClassWithID(claseContenedor, id, contenido, clase) {
		let sHtml = "id=" + id + " class='" + clase + "'>" + contenido;
		let contenedor = document.querySelector(claseContenedor)
		this.creaContenedor(sHtml, contenedor);
	}

	creaContenedorByClass(claseContenedor, contenido, clase) {
		let sHtml = "class='" + clase + "'>" + contenido;
		let contenedor = document.querySelector(claseContenedor)
		this.creaContenedor(sHtml, contenedor);
	}

	creaContenedorById(idContenedor, contenido, clase) {
		let sHtml = "class='" + clase + "'>" + contenido;
		let contenedor = document.getElementById(idContenedor);

		this.creaContenedor(sHtml, contenedor);
	}

	creaContenedor(sHtml, contenedor) {
		let elemento = document.createElement("DIV");

		elemento.innerHTML = "<div " + sHtml + "</div>";
		contenedor.appendChild(elemento);
	}

	creaBoton(id, stexto, claseContenedor, clase) {
		let elemento = document.createElement("BUTTON");
		let texto = document.createTextNode(stexto);
		let contenedor = document.querySelector(claseContenedor);

		elemento.appendChild(texto);
		elemento.id = id;
		elemento.className = clase;
		contenedor.appendChild(elemento);
	}

	creaBotonbyID(id, stexto, idContenedor, clase) {
		let elemento = document.createElement("BUTTON");
		let texto = document.createTextNode(stexto);
		let contenedor = document.getElementById(idContenedor);

		elemento.appendChild(texto);
		elemento.id = id;
		elemento.className = clase;
		contenedor.appendChild(elemento);
	}

	creaInput(id, claseContenedor, clase, texto) {
		let elemento = document.createElement('INPUT');
		let contenedor = document.querySelector(claseContenedor);

		elemento.id = id;
		elemento.className = clase;
		elemento.placeholder = texto;
		contenedor.appendChild(elemento);
	}

	creaHidden(id, claseContenedor) {
		let elemento = document.createElement('INPUT');
		let contenedor = document.querySelector(claseContenedor);

		elemento.id = id;
		elemento.setAttribute("type", "hidden");
		contenedor.appendChild(elemento);
	}

	obtenValorByID(nombre) {
		var elemento = document.getElementById(nombre);
		return elemento.value;
	}

	ponValorByID(nombre, texto) {
		var elemento = document.getElementById(nombre);
		elemento.value = texto;
	}
}

class Contacto {
	constructor(nombre = null, apellidos = null, email = null, urlfoto = null, id = null) {
		this._nombre = nombre;
		this._apellidos = apellidos;
		this._email = email;
		this._urlFoto = urlfoto;
		this._id = id;
	}

	pintar() {
		let formulario = new Formulario();
		formulario.creaContenedorByClassWithID(".lista", "contacto" + this._id, "contacto");
		creaBotonbyID("btnEditContacto" + this._id, "Editar", "contacto" + this._id, "btnContacto");
		creaBotonbyID("btnDelContacto" + this._id, "Borrar", "contacto" + this._id, "btnContacto");
	}
}

class Agenda {
	constructor(contactos = [], seqcontactos = 0) {
		this._id = "Agenda";
		this._contactos = contactos;
		this._seqContactos = seqcontactos;
		//this._clienteAPIPersonajes = new ClienteApiPersonajes();
	}

	static construyeAgendaConObjeto(agendaComoObjeto) {
		let agenda = new Agenda(agendaComoObjeto._contactos, agendaComoObjeto._seqcontactos);
		let contactos = [];

		for(let i=0; i<agenda._contactos.length; i++) {
			let objeto = agenda._contactos[i];
			let contacto = new Contacto();

			for(let prop in objeto) {
				contacto[prop] = objeto[prop];
			}

			contactos.push(contacto);
		}

		agenda._contactos = contactos
	}

	setContacto(contacto) {
		let formulario = new Formulario();

		formulario.ponValorByID("txtNombre", contacto._nombre);
		formulario.ponValorByID("txtApellidos", contacto._apellidos);
		formulario.ponValorByID("txtEmail", contacto._email);
		formulario.ponValorByID("txtUrlFoto", contacto._urlFoto);
		formulario.ponValorByID("txtID", contacto._id);
	}

	getContacto(isNew) {
		let formulario = new Formulario();
		let contacto = new Contacto;

		contacto._nombre = formulario.obtenValorByID("txtNombre");
		contacto._apellidos = formulario.obtenValorByID("txtApellidos");
		contacto._email = formulario.obtenValorByID("txtEmail");
		contacto._urlFoto = formulario.obtenValorByID("txtUrlFoto");
		if(isNew) {
			contacto._id = this.seqcontactos++;
		} else {
			contacto._id = formulario.obtenValorByID("txtID");
		}

		return contacto;
	}

	findContacto() {
		let contacto = this.getContacto(false);
		let contactoIndex;

		for(let i=0; i<this._contactos.length; i++) {
			if(!contactoIndex && this._contactos[i]._id == contacto._id) {
				contactoIndex = this._contactos[i];
			}
		}

		return contactoIndex;
	}

	addContacto() {
		let contacto = this.getContacto(true);
		this._contactos.push(contacto);
		this.pintarContactos();
	}

	deleteContacto(contacto) {
		let index = this._contactos.indexOf(contacto);
		this._contactos.splice(index, 1);
		this.pintarContactos();
	}

	updContacto() {
		let contacto = findContacto();
		let index = this._contactos.indexOf(contacto);
		this._contactos[index] = contacto;
		this.pintarContactos();
	}

	pintarContactos() {
		this._contactos.forEach((contacto) => contacto.pintar());
		for(let i=0; i<this._contactos.length; i++) {
			let contacto = this._contactos[i];
			document.getElementById("btnEditContacto" + contacto._id).addEventListener("click", () => this.btnEditContacto(contacto));
			document.getElementById("btnDelContacto" + contacto._id).addEventListener("click", () => this.btnDeleteContacto(contacto));
		}
	}

	pintaEstructura() {
		let formulario = new Formulario();
		//Creando contenedor principal
		let elemento = document.createElement("DIV");
		elemento.innerHTML = "<div id='" + this._id + "'></div>";
		document.body.appendChild(elemento);

		//Creando contenedores de la aplicación
		formulario.creaContenedorById(this._id, "", "forma");
		formulario.creaContenedorById(this._id, "", "lista");

		this.pintaControles();
		this.pintarContactos();
	}

	pintaControles() {
		let formulario = new Formulario();
		let sHtml = "";

		sHtml += "<h3>Añadir Contacto</h3>";

		document.querySelector(".botones").innerHTML = sHtml;
		
		formulario.creaInput("txtNombre", ".botones", "input", "Nombre");
		formulario.creaInput("txtApellidos", ".botones", "input", "Apellidos");
		formulario.creaInput("txtEmail", ".botones", "input", "email");
		formulario.creaInput("txtUrlFoto", ".botones", "input", "URL Foto");
		formulario.creaHidden("txtID", ".botones");

		formulario.creaBoton("btnAddContacto", "Guardar", ".botones", "button-main");
		document.getElementById("btnAddContacto").addEventListener("click", () => this.btnAddContacto());
		formulario.creaBoton("btnCerrarContacto", "Cerrar", ".botones", "button-main");
		document.getElementById("btnCerrarContacto").addEventListener("click", () => this.cerrarForma());
	}
}

class AlmacenAgenda {
	constructor() {
		this._agenda = this.getNewAgenda();
	}

	getNewAgenda() {
		if(!this.getAgendaFromLocalStorage()){
	    	this._agenda = new Agenda();
	 		this.setAgendaAtLocalStorage(this._agenda);
		} else {
	    	let objeto = this.getAgendaFromLocalStorage();
	    	this._agenda = Agenda.construyeAgendaConObjeto(objeto);
		}
	}

	getAgendaFromLocalStorage(){
	    let agendaAsString = localStorage.getItem("agenda");
	    let agenda = JSON.parse(personaAsString);
	    return agenda;
	}

	setAgendaAtLocalStorage(agenda){
	    let agendaAsString = JSON.stringify(agenda);
	    localStorage.setItem("agenda", agendaAsString);
	}
}

window.onload = () => {
	almacen = new AlmacenAgenda(); 
	agenda = almacen._agenda ;
	agenda.pintarEstructura();
}