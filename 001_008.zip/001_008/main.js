var obtenMedia = function(cadenaNumeros) {
	var res = cadenaNumeros.split(":");
	var indice = 0;
	var suma = 0;
	var media = 0;
	
	for(indice=0; indice<res.length; indice++) {
		suma += parseInt(res[indice]);
	}

	media = suma / indice;
	return media;
}

var eliminarRepetidos = function(cadenaNumeros) {
	var res = cadenaNumeros.split(":");
	var cadenaNueva = '';

	for(indice=0; indice<res.length; indice++) {
		for(subindice=indice+1; subindice<res.length; subindice++) {
			if(res[indice] === res[subindice]) {
				res[subindice] = 0;
			}
		}
	}

	for(indice=0; indice<res.length; indice++) {
		if(parseInt(res[indice]) !== 0) {
			cadenaNueva += res[indice] + ":";
		}
	}
	
	cadenaNueva = cadenaNueva.substring(0,cadenaNueva.length - 1)
		
	return cadenaNueva;
}

console.log(obtenMedia("80:70:90:100"));
console.log(eliminarRepetidos("80:70:90:100:100:100"));
console.log(obtenMedia(eliminarRepetidos("80:70:80:90:100:100:100")));