var calculoDNI = function(numeroDNI) {
	var letra = "";
	var snumeroDNI = "" + numeroDNI;
	var tablaLetras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'];
	
	if (typeof(numeroDNI) != 'number') {
		letra = 'Introduce un numero';
	} else if (snumeroDNI.length != 8) {
	  if (snumeroDNI.length > 8) {
		  letra = 'Introduce un número de 8 dígitos';
	  } else {
	    for(var i=snumeroDNI.length; i<8; i++) {
	      snumeroDNI = '0' + snumeroDNI;
	      letra = tablaLetras[numeroDNI%23];
	    }
	  }
	} else if(numeroDNI < 0) {
		letra = 'Introduce un valor positivo';
	} else {
		letra = tablaLetras[numeroDNI%23];
	}

	return letra;
}

console.log ("la letra del DNI HolaK es: ");
console.log(calculoDNI('Hola'));

console.log ("la letra del DNI 123123123K es: ");
console.log(calculoDNI(123123123));

console.log ("la letra del DNI 1231231K es: ");
console.log(calculoDNI(1231231));

console.log ("la letra del DNI -1231231K es: ");
console.log(calculoDNI(-1231231));

console.log ("la letra del DNI 12312312K es: ");
console.log(calculoDNI(12312312));

