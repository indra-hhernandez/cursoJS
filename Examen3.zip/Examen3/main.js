/*
1) 1 Punto

Modela la clase Pokedex, la cual será nuestra enciclopedia de pokemons.
La clase Pokedex deberá tener:

- Array de Pokemons (contendrá solo los pokemons de la página en la que nos encontremos)
- Página actual (numérico)
- Número total de pokemons

Modela la clase Pokemon. Pokemon deberá tener:

- Nombre
- UrlDetalle

2) 1 Punto

Modela la clase ApiClient que se encargue de realizar peticiones get genéricas.
Sólo recibirá la URL sobre la que ejecutará la petición y debe devoler el body de respuesta ya parseado.
Se valorará el uso de Promesas en vez de callbacks.

4) 2 Puntos

Modela la clase PokemonApi que ofrezca:

- El método getPokemonsAtPage(numeroPagina): que devuelva el array de Pokemon de esa página.
- El método getPokemonByUrl(urlDePokemon): que devuelva el Pokemon de esa URL.

Esta clase deberá hacer uso de la clase ApiClient para pedir que haga el get de las URLs que necesite.
Al igual que en el anterior se valorará el uso de Promesas en vez de callbacks.

5) 2 Puntos 

Implementa las funciones pintarEstructura() y pintarPagina() en la clase pokedex .
Por ahora solo HTML y CSS, la funcionalidad de los botones puedes hacerla más tarde.

	pintarEstructura() debe pintar la estructura básica de la Pokedex:
	
		En la parte superior tendremos un paginador que tendrá:
			- Número de página actual.
			- Botón de página siguiente y página anterior

		En la parte media mostrará una tabla con los pokemons. La tabla tendrá 2 columnas: 
			- Nombre: tendrá el nombre del pokemon
			- Acciones. tendrá un botón ver detalles cuya acción implementaremos más tarde

	pintarPagina() debe rellenar la tabla con los pokemons de la página actual.


5) 1 Puntos

Haz que al cargar la página:
	- Se pinte la estructura de la pokedex.
	- Se pida la página 1
	- Se pinte la página actual

6) 1 Puntos

Implementa el paginador.
Cuando pulsemos en siguiente o anterior deberás pedir la página que corresponda al PokemonClient y posteriormente pintarla.

7) 2 Puntos

Implementa la funcionalidad del botón ver detalles:

	- Deberás pedir los detalles de ese Pokemon llamando a la función getPokemonByUrl de PokemonApi.
	- Deberás mostrar los detalles de ese pokemon, al menos:
		- Nombre
		- Una imagen (cualquiera dentro del array sprites)
		- Peso (weight)
		- Altura (height)

	Puedes hacer uso de una modal o mostrar los detalles debajo de la propia tabla.



INFO DE LA API:

URL de la API: http://pokeapi.co/api/v2/pokemon
URL de la API paginada: http://pokeapi.co/api/v2/pokemon/?offset=0

El offset en la API paginada es el número de pokemons que nos "saltamos", 
puesto que esta API devuelve los resultados de 20 en 20 para paginar debemos saltar de 20 en 20

Por ejemplo:

Página 1: http://pokeapi.co/api/v2/pokemon/?offset=0
Página 2: http://pokeapi.co/api/v2/pokemon/?offset=20
Página 3: http://pokeapi.co/api/v2/pokemon/?offset=40
..
..
..
Página n: offset = (n-1)*20


*/
class Formulario {
	constructor() {}

	creaContenedorByClass(claseContenedor, contenido, clase) {
		let sHtml = "class='" + clase + "'>" + contenido;
		let contenedor = document.querySelector(claseContenedor)
		this.creaContenedor(sHtml, contenedor);
	}

	creaContenedorById(idContenedor, contenido, clase) {
		let sHtml = "class='" + clase + "'>" + contenido;
		let contenedor = document.getElementById(idContenedor);

		this.creaContenedor(sHtml, contenedor);
	}

	creaContenedor(sHtml, contenedor) {
		let elemento = document.createElement("DIV");

		elemento.innerHTML = "<div " + sHtml + "</div>";
		contenedor.appendChild(elemento);
	}

	creaBoton(id, stexto, claseContenedor, clase) {
		let elemento = document.createElement("BUTTON");
		let texto = document.createTextNode(stexto);
		let contenedor = document.querySelector(claseContenedor);

		elemento.appendChild(texto);
		elemento.id = id;
		elemento.className = clase;
		contenedor.appendChild(elemento);
	}

	creaInput(id, claseContenedor, clase, texto) {
		let elemento = document.createElement('INPUT');
		let contenedor = document.querySelector(claseContenedor);

		elemento.id = id;
		elemento.className = clase;
		elemento.placeholder = texto;
		contenedor.appendChild(elemento);
	}
}

class Pokedex {
	constructor() {
		this._pokemons = [];
		this._currentPage = 1;
		this._totalPokemos = 0;
		this._itemsPPagina = 20;
		this._id = "Pokexamen";
		this._pokemonApi = new PokemonApi();
	}

	pintarEstructura() {
		let formulario = new Formulario();
    	//Creando contenedor principal
		let elemento = document.createElement("DIV");
		elemento.innerHTML = "<div id='" + this._id + "'></div>";
		document.body.appendChild(elemento);

		//Creando contenedores de la aplicación
		formulario.creaContenedorById(this._id, "", "paginador");
		formulario.creaContenedorById(this._id, "", "lista");
		formulario.creaContenedorById(this._id, "", "detalle");

		formulario.creaBoton("btnPrev", "<Anterior", ".paginador", "button-main");
		document.getElementById("btnPrev").addEventListener("click", () => this.pagAnterior());
		formulario.creaInput("txtPagina", ".paginador", "inputForm", "Página 1");
		formulario.creaBoton("btnNext", "Siguiente>", ".paginador", "button-main");
		document.getElementById("btnNext").addEventListener("click", () => this.pagSiguiente());
	}

	pagAnterior() {
		if(this._currentPage > 1) {
			this._currentPage--;
			document.getElementById("txtPagina").value = this._currentPage;
			this.pintarPagina();
		}
	}

	pagSiguiente() {
		if(this._currentPage * this._itemsPPagina < this._totalPokemos) {
			this._currentPage++;
			document.getElementById("txtPagina").value = this._currentPage;
			this.pintarPagina();
		}
	}

	pintarPagina() {
		let itemInicial = (this._currentPage-1) * this._itemsPPagina;

		this._pokemonApi.getPokemonsAtPage(itemInicial).then(
    		(data) => {
    			this._totalPokemos = data.total;
    			this._pokemons = data.items;
    			document.querySelector(".lista").innerHTML = this.pintaTabla();
    		}
   		);

   		document.querySelector(".detalle").innerHTML = "";
   	}

   	pintarDetalle(url) {
		this._pokemonApi.getPokemonByUrl(url).then(
    		(data) => {
    			document.querySelector(".detalle").innerHTML = data.pintarDetalle();
    		}
   		);
   	}

   	pintaTabla() {
		let sHtml = "";

		sHtml += "<h3>Lista de Pokemons</h3>";
		sHtml += "<table>";
		sHtml += "<thead><tr><td>Nombre</td><td>Acciones</td></tr></thead>";
		sHtml += "<tbody>";
		sHtml += "<tbody>" + this.pintaDatos(this._pokemons) + "</tbody>";
		sHtml += "</table>";

		return sHtml;
	}

	pintaDatos(data) {
		let sHtml = "";
		for(let i=0; i<data.length; i++) {
			sHtml += data[i].pintar();
		}
		return sHtml;
	}
}

class Pokemon {
	constructor(name, url) {
		this._name = name;
		this._urlDetail = url;
		this._peso = "";
		this._altura = "";
		this._imagenes = [];
	}

	pintarDetalle() {
		return "<img src='" + this._imagenes[0]._url + "'><br/>Nombre: " + this._name + "<br/>Peso: " + this._peso + "<br/>Altura: " + this._altura;
	}

	pintar() {
		return "<tr><td>" + this._name + "</td><td><input type='button' class='button-detalle' value='Ver Detalles' onclick='pokedex.pintarDetalle(\"" + this._urlDetail + "\")'></td></tr>";
	}
}

class ImagenPokemon {
	constructor(descripcion, url) {
		this._descripcion = descripcion;
		this._url = url;
	}
}

class ApiClient {
	constructor() {
	}

	get(url) {
		let cabeceras = new Headers();
		let init = {
			method: 'GET',
			headers: cabeceras
		};

		let promise = fetch(url, init).then(
			(response) => {
				return response.json();
			}
		);

		return promise;
	}
}

class PokemonApi {
	constructor() {
		this._urlBase = "http://pokeapi.co/api/v2/pokemon";
		this._apiClient = new ApiClient();
	}

	getPokemonsAtPage(index) {
		let urlCompleta = this._urlBase + "/?offset=" + index;
		let promise = this._apiClient.get(urlCompleta).then(
			(respuesta) => {
				let objLista = respuesta.results;
				let arrayPokemons = [];

				for(let i=0; i<objLista.length; i++) {
					let elem = objLista[i];
					let pokemon = new Pokemon(elem.name, elem.url);
					arrayPokemons.push(pokemon);
				}

				return {
					total: respuesta.count,
					items: arrayPokemons
				};
			}
		);

		return promise;
	}

	getPokemonByUrl(urlCompleta) {
		let promise = this._apiClient.get(urlCompleta).then(
			(respuesta) => {
				let images = [];
				let sprites = respuesta.sprites;
				let pokemon = new Pokemon(respuesta.name, respuesta.occupation, respuesta.weight, respuesta.height);
				
				for(let prop in sprites) {
					if(sprites[prop]) {
						images.push(new ImagenPokemon(prop, sprites[prop]));
					}
				}

				pokemon._imagenes = images;
				return pokemon;
			}
		);

		return promise;
	}
}

var pokedex;

window.onload = () => {
	pokedex = new Pokedex();
	pokedex.pintarEstructura();
	pokedex.pintarPagina();
}