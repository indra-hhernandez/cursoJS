//Definición de globales
var nombresPersona = ["Victor", "Omar", "Karen", "Ariel", "Omar", "David", "Esteban", "Matías", "Vlairner", "Lucy", "Ignacio", "Humberto", "Nestor", "Daniel", "Raymundo"];
var cargosCamarero = ["Encargado", "Mozo"];

var nombreComida = ["Recado Negro", "Durango en Pulque", "Del campo", "Mediterranea", "MedMex"];
var nombreEntrante = ["Arrenque a la Crema", "Cazuela de tuetano", "Carnitas de Pato", "Camarones y setas al ajillo", "Quesadillas lacandonas"];
var nombrePrincipal = ["Fetuccini Alfredo", "Ravioles rellenos", "Pastrami Kosher", "Filete de róbalo", "Pierna de ternera"];
var nombrePostre = ["Creme Brulee", "Tarta de Almendras", "Profiteroles", "Sorbete de Mango", "Cheese Cake de Guayaba"];
var nombreBebidad = ["Cisne Negro", "Via del campo", "Cucaracha", "Martini", "Flirtini"];

var titulosBebidas = ["Nombre", "Grado de Alcohol", "Precio"];
var titulosComidas = ["Nombre", "Tiempos", "Precio"];

const NUMCOMIDAS = 5;
const NUMMESAS = 30;
const NUMCAMAREROS = 5;

function getRandomInteger(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generarDatoAleatorio(opciones) {
	var numeroAleatorio = Math.floor(Math.random() * opciones.length);
	return opciones[numeroAleatorio];
}

class Persona {
	constructor() {
		this._nombre = generarDatoAleatorio(nombresPersona);
		this._edad = getRandomInteger(20, 60);
	}
}

class Cliente extends Persona {
	constructor() {
		super();
		this._dinero = getRandomInteger(0, 1500);
	}
}

class Camarero extends Persona {
	constructor() {
		super();
		this._cargo = generarDatoAleatorio(cargosCamarero);
	}

	toHTML() {
		return "<div class='divmesero divmesero" + (this._cargo == "Mozo" ? "_m" : "_e") + "'>" + this._nombre + "</div>";
	}
}

class Mesa {
	constructor(id) {
		this._mesaId = id;
		this._capacidad = getRandomInteger(2, 10);
		this._ocupada = false;
		this._personas = [];
		this._ordenes = [];
	}

	toHTML() {
		return "<div class='divmesa divmesa" + (this._ocupada ? "_o" : "_d") + "'>" + this._mesaId + "<br/>" + this._personas.length + "/" + this._capacidad + "</div>";
	}
}

class Producto {
	constructor(nombre) {
		this._nombre = nombre;
		this._existencias = getRandomInteger(2, 20);
		this._calorias = getRandomInteger(100, 500);
		this._precio = getRandomInteger(30, 200);
	}
}

class Comida extends Producto {
	constructor(nombre, entrante, principal, postre) {
		super(nombre);
		this._entrante = generarDatoAleatorio(nombreEntrante);
		this._principal = generarDatoAleatorio(nombrePrincipal);
		this._postre = generarDatoAleatorio(nombrePostre);
	}

	toHTML() {
		return "<tr><td>" + this._nombre + "</td><td>" + this._entrante + "/" + this._principal + "/" + this._postre + "</td><td>" + this._precio + "</td></tr>";
	}
}

class Bebida extends Producto {
	constructor(nombre) {
		super(nombre);
		this._esAlcoholica = (getRandomInteger(1, 2) == 1) ? true : false;
		this._gradoAlcohol = getRandomInteger(3, 20);
	}

	toHTML() {
		return "<tr><td>" + this._nombre + "</td><td>" + (this._esAlcoholica ? this._gradoAlcohol : 0) + "</td><td>" + this._precio + "</td></tr>";
	}
}

class Restaurante {
	constructor(nombre) {
		this._nombre = nombre;
		this._mesas = [];
		this._camareros = [];
		this._carta = new Carta();
		this._contadorMesas = 0;

		for(let i=0; i<NUMMESAS; i++){
			this._mesas.push(new Mesa(++this._contadorMesas));
		}

		for(let i=0; i<NUMCAMAREROS; i++){
			this._camareros.push(new Camarero());
		}
	}

	getMesasHTML() {
		let sHtml = "<div id='divMesas' class='renglon_sup'>";

		for(let i=0; i<this._mesas.length; i++){
			sHtml += "<div>" + this._mesas[i].toHTML() + "</div>"
		}

		return sHtml + "</div>";
	}

	getCamarerosHTML() {
		let sHtml = "<div id='divMeseros' class='renglon_sup'>";

		for(let i=0; i<this._camareros.length; i++){
			sHtml += "<div>" + this._camareros[i].toHTML() + "</div>"
		}

		return sHtml + "</div>";
	}
}

class Carta {
	constructor() {
		this._comidas = [];
		this._bebidas = [];

		for(let i=0; i<NUMCOMIDAS; i++){
			this._comidas.push(new Comida(generarDatoAleatorio(nombreComida)));
			this._bebidas.push(new Bebida(generarDatoAleatorio(nombreBebidad)));
		}
	}

	toHTML(){
		let sHtml = "<h2>Nuestra carta:</h2>";
		sHtml += this.getTablaHTML("Bebidas", titulosBebidas, this._bebidas);
		sHtml += this.getTablaHTML("Comidas", titulosComidas, this._comidas);

		return sHtml;
	}

	getTablaHTML(titulo, titulos, datos) {
		let sHtml = "";

		sHtml += "<h3>" + titulo + ":</h3>";
		sHtml += "<table>";
		sHtml += "<thead>";
		sHtml += this.getTitulosHTML(titulos);
		sHtml += "</thead>";
		sHtml += "<tbody>";
		sHtml += this.getDatosHTML(datos);
		sHtml += "</tbody>";
		sHtml += "</table>";

		return sHtml;
	}

	getTitulosHTML(titulos) {
		let sHtml = "";

		for(let i=0; i<titulos.length; i++){
			sHtml += "<td>" + titulos[i] + "</td>"
		}

		return sHtml;
	}

	getDatosHTML(datos) {
		let sHtml = "";

		for(let i=0; i<datos.length; i++){
			sHtml += "<td>" + datos[i].toHTML() + "</td>"
		}

		return sHtml;
	}
}

miRestaurante = new Restaurante("¡Comes y Te Vas!");

window.onload = function() {
	document.getElementById("divMenu").innerHTML = "<h1>" + miRestaurante._nombre + "</h1>" + miRestaurante._carta.toHTML();
	document.getElementById("divMapa").innerHTML = miRestaurante.getMesasHTML() + miRestaurante.getCamarerosHTML();
}