function loadScript(src) {
	var promesa = new Promise( function (resolve, reject) {
		var elem = document.createElement('script');
		elem.setAttribute('type', 'text/javascript');
		elem.setAttribute('src', src);
		elem.onload = function() { resolve(src) };
		elem.onerror = function() { reject("Error al cargar " + src) };
		document.documentElement.insertBefore(elem, null);
	});

	return promesa;
}

function testPromesa() {
	loadScript('https://code.jquery.com/jquery-3.2.1.slim.min.js').then(
			function(result) {
				console.log("Genial, hemos cargado: " + result);
				console.log(jQuery);
			}, 
			function(error) {
				console.error(error);
			}
		);
}

function testPromesaConError() {
	loadScript('https://urlque.noexiste').then(
			function(result) {
				console.log("Genial, hemos cargado: " + result);
				console.log(jQuery);
			},
			function(error) {
				console.error(error);
			}
		);
}