function loadScript(src) {
	var promesa = new Promise( function (resolve, reject) {
		var elem = document.createElement('script');
		elem.setAttribute('type', 'text/javascript');
		elem.setAttribute('src', src);
		elem.onload = function() { resolve(src) };
		elem.onerror = function() { reject("Error al cargar " + src) };
		document.documentElement.insertBefore(elem, null);
	});

	return promesa;
}

function testPromesa() {
	loadScript('https://code.jquery.com/jquery-3.2.1.slim.min.js').then(
			function(result) {
				console.log("Genial, hemos cargado: " + result);
				console.log(jQuery);
			}, 
			function(error) {
				console.error(error);
			}
		);
}

function testPromesaConError() {
	loadScript('https://urlque.noexiste').then(
			function(result) {
				console.log("Genial, hemos cargado: " + result);
				console.log(jQuery);
			},
			function(error) {
				console.error(error);
			}
		);
}

function testMultiplesPromesas() {
	var promesa1 = loadScript('https://code.jquery.com/jquery-3.2.1.slim.min.js');
	var promesa2 = loadScript('https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.4/lodash.js');
	
	Promise.all([promesa1, promesa2]).then(
			function(result) {
				console.log("Todas las promesas se han cargado correctamente");
				console.log(result);
			},
			function(error) {
				console.error(error);
			}
		);
}

function testMultiplesPromesasConManejoIndependiente() {
	var promesa1 = loadScript('https://code.jquery.com/jquery-3.2.1.slim.min.j').catch(
			function(error) {
				console.log("Ha ocurrido un error en promesa 1");
				throw(error);
			}
		);
	var promesa2 = loadScript('https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.4/lodash.js');
	
	Promise.all([promesa1, promesa2]).then(
			function(result) {
				console.log("Todas las promesas se han cargado correctamente");
				console.log(result);
			},
			function(error) {
				console.log("Error en alguna promesa");
				console.log(error);
			}
		);
}