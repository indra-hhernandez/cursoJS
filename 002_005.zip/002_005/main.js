/*1) Realiza la modelización de un parque natural. Empieza con el siguiente código.

var parqueNatural = {
areas = [],
parqueDeBomberos = {}
}

En cada una de las áreas (añade 10 áreas) encontraremos un array de árboles (100 por área) y un array de visitantes (100 en todo el parque).
En el parque de bomberos encontraremos un array de bomberos (10) y posiblemente más propiedades que se te puedan ocurrir.
Los bomberos y los visitantes deberán heredar de la clase Persona.

2) Añade un método ejecutar ciclo que represente el paso de 1h en el parque.
Cada ciclo que pase debemos llamar a ejecutar ciclo de los visitantes que se irán cambiando de area de forma aleatoria.
Haz que el método se ejecute cada segundo.

3) En cada paso de un ciclo se puede originar un fuego (probabilidad del 5%) que empezaría quemando un arbol aleatorio dentro del parque.
Cada ciclo que pase el fuego se extenderá al arbol al arbol siguiente, si no hay arbol siguiente, deberá saltar al primer arbol del área siguiente.
Asi sucesivamente hasta expandirse por todo el parque. Cada ciclo que pase el fuego en los arboles, estos estarán un 10% más quemados.
Cuando lleguen al 100% de quemados, se habrá perdido el arbol. (Quitarlo del área).​
*/

/*1) Añade un objeto viento​ (de clase viento), con el siguiente atributo:
Velocidad: Nula/Media/Alta
En cada ejecución el viento tendrá una velocidad aleatoria
Si la velocidad es nula el incendio se expandirá 1 arbol, si la velocidad es media: dos árboles, si la dirección es alta: 3 árboles.
2) Los incendios ya no se originan de forma aleatoria en cualquier parte del bosque.
Los incendios los pueden originar los visitantes que sean fumadores (2 de cada 10). En cada ciclo hay una probabilidad del 10% de que un visitante fumador tire una colilla en el área en el que está y provoque un incendio.
*/

//Definiendo Globales
var nombresPersona = ["Victor", "Omar", "Karen", "Ariel", "Omar", "David", "Esteban", "Matías", "Vlairner", "Lucy", "Ignacio", "Humberto", "Nestor", "Daniel", "Raymundo"];
var totalVisitantes = 100;
var avanceQuemado = 10;

function getRandomInteger(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generarNombreAleatorio() {
	var numeroAleatorio = Math.floor(Math.random() * nombresPersona.length);
	return nombresPersona[numeroAleatorio];
}

//Definiendo Parque
var ParqueNatural = function() {
	this._areas = [];
	this._parqueBomberos = new ParqueBomberos();

	for(var iArea=0; iArea<10; iArea++) {
		this._areas.push(new Area(iArea));
	}

	for(var iBombero=0; iBombero<10; iBombero++) {
		this._parqueBomberos._bomberos.push(new Bombero(iBombero));
	}
}

ParqueNatural.prototype.addVisitante = function() {
	var visitantes = 0;

	for(var iArea=0; iArea<this._areas.length; iArea++) {
		visitantes += this._areas[iArea]._visitantes.length;
	}

	if(visitantes < totalVisitantes) {
		var areaAleatoria = getRandomInteger(0, this._areas.length-1);
		this._areas[areaAleatoria]._visitantes.push(new Visitante());
	}
}

ParqueNatural.prototype.addVisitantes = function() {
	var cantidad = getRandomInteger(1, 20);
	
	for (var i=0; i<cantidad; i++) {
		this.addVisitante();
	}
}

ParqueNatural.prototype.ocurreIncendio = function() {
	var probabilidad = getRandomInteger(1, 20);
	var iarea = 0;
	var iarbol = 0;
	var incendio = false;

	if(probabilidad == 1) {
		while(!incendio) {
			iarea = getRandomInteger(1, this._areas.length)-1;
			if(this._areas[iarea]._arboles.length > 0) {
				iarbol = getRandomInteger(1, this._areas[iarea]._arboles.length)-1;
				console.log("Intentando incendio area " + iarea + " arbol " + iarbol);
				var arbol = this._areas[iarea]._arboles[iarbol];
				if(!arbol._incendiado) {
					arbol._incendiado = true;
					incendio = true;
					console.log("Nuevo incendio area " + iarea + " arbol " + iarbol);
				}
			}
		}
	}
}

ParqueNatural.prototype.avanceIncendio = function() {
	for(var iarea=0; iarea<this._areas.length; iarea++) {
		for(var iarbol=this._areas[iarea]._arboles.length-1; iarbol>=0; iarbol--) {
			var arbol = this._areas[iarea]._arboles[iarbol];
			arbol.cicloArbol();

			if(arbol._incendiado) {
				if(iarbol == this._areas[iarea]._arboles.length-1) {
					if(iarea == this._areas.length-1) {
						if(this._areas[0]._arboles.length > 0) {
							this._areas[0]._arboles[0]._incendiado = true;
						}
					}
					else {
						if(this._areas[iarea+1]._arboles.length > 0) {
							this._areas[iarea+1]._arboles[0]._incendiado = true;
						}
					}
				} else {
					this._areas[iarea]._arboles[iarbol+1]._incendiado = true;
				}
			}
		}
	}
}

ParqueNatural.prototype.eliminarQuemados = function() {
	for(var iarea=0; iarea<this._areas.length; iarea++) {
		for(var iarbol=0; iarbol<this._areas[iarea]._arboles.length; iarbol++) {
			var arbol = this._areas[iarea]._arboles[iarbol];
			
			if(arbol._quemado == 100) {
				this._areas[iarea]._arboles.splice(iarbol,1);
			}
		}
	}
}

ParqueNatural.prototype.cambioArea = function() {
	for(var iarea=0; iarea<this._areas.length; iarea++) {
		for(var ivisitante=0; ivisitante<this._areas[iarea]._visitantes.length; ivisitante++) {
			this._areas[iarea]._visitantes[ivisitante].cicloVisitante(this._areas[iarea]);
		}
	}
}

ParqueNatural.prototype.verTabla = function() {
	var tablaHTML = "<table>";

	for(var iarea=0; iarea<this._areas.length; iarea++) {
		tablaHTML += "<tr>";
		for(var iarbol=this._areas[iarea]._arboles.length-1; iarbol>=0; iarbol--) {
			var arbol = this._areas[iarea]._arboles[iarbol];
			
			tablaHTML += "<td id="+iarea+"_"+iarbol+">";
			if(arbol._incendiado) {
				if(arbol._quemado == 100) {
					tablaHTML += "|";
				} else {
					tablaHTML += "*";
				}
			} else {
				tablaHTML += ".";
			}
			tablaHTML += "</td>";
		}
		tablaHTML += "</tr>";
	}
	tablaHTML += "</table>";

	document.getElementById('tablaHtml').innerHTML = tablaHTML;
}

ParqueNatural.prototype.fin = function() {
	var arboles = 0;
	
	for(var iArea=0; iArea<this._areas.length; iArea++) {
		arboles += this._areas[iArea]._arboles.length;
	}

	return (arboles == 0);
}

var Viento = function() {
	this.direccion = 0;
	this.velocidad = 0;
}

//Definiendo parque bomberos
var ParqueBomberos = function() {
	this._bomberos = [];
}

//Definiendo Area
var Area = function(id) {
	this._areaId = id;
	this._arboles = [];
	this._visitantes = [];

	for(var i=0; i<100; i++) {
		this._arboles.push(new Arbol(id));
	}
}

//Definiendo Arbol
var Arbol = function(idArea, idArbol) {
	this._areaId = idArea;
	this._incendiado = false;
	this._quemado = 0;
}

Arbol.prototype.cicloArbol = function() {
	if(this._incendiado) {
		if(this._quemado >= 100) {
			this._quemado = 100;
		} else {
			this._quemado += avanceQuemado;
		}
	}
}

//Definiendo Persona
var Persona = function() {
	this._nombre = generarNombreAleatorio();
}

//Definiendo Bombero
var Bombero = function() {
}

Bombero.prototype = new Persona();

//Definiendo Visitante
var Visitante = function() {
	this._fumador = (getRandomInteger(1, 10) < 2) ? true : false;
}

Visitante.prototype = new Persona();

Visitante.prototype.cicloVisitante = function(area) {
	var areaIndice = getRandomInteger(0, 9);
	var visitanteId = area._visitantes.indexOf(this);
	area._visitantes.splice(visitanteId, 1);
	parque._areas[areaIndice]._visitantes.push(this);
}

parque = new ParqueNatural();

function cicloParque() {
	parque.addVisitantes();
	parque.cambioArea();
	parque.eliminarQuemados();
	parque.avanceIncendio();
	parque.ocurreIncendio();
	if(parque.fin()) {
		clearInterval(intervalID);
		console.log("Parque consumido");
	}
	parque.verTabla();
}

var intervalID = setInterval(cicloParque, 1000);