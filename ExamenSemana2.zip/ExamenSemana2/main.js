//Definiendo globales
var ropa = ["camisa", "chamarra", "cinturon", "pantalon", "sueter", "vestido", "zapatos"];

//Definiendo Tienda
var Tienda = function() {
	this._productos = [];
	this._nombre = "";
	this._url = "";
}

Tienda.prototype.addProducto = function() {
	var producto = new Producto();
	producto.initProducto();

	if(producto._datosCorrectos) {
		producto.limpiarForma();
		this._productos.push(producto);
		this.verTienda();
	}
}

Tienda.prototype.delProducto = function(idProducto) {
	this._productos.splice(idProducto, 1);
	this.verTienda();
}

Tienda.prototype.verTienda = function() {
	var tablaHTML = "";
	
	if(this._productos.length > 0) {
		tablaHTML += "<table class='tabla'>";
		tablaHTML += "<tr><th>Imagen</th><th>Nombre</th><th>Precio</th><th>Descripcion</th><th>Acciones</th></tr>";

		for(var i=0; i<this._productos.length; i++) {
			var producto = this._productos[i];
			tablaHTML += "<tr>";
			tablaHTML += "<td><img src='img/" + producto._urlImagen + ".jpeg' height='30' width='30'></td>";
			tablaHTML += "<td>" + producto._nombre + "</td>";
			tablaHTML += "<td>$" + producto._precio + "</td>";
			tablaHTML += "<td>" + producto._descripcion + "</td>";
			tablaHTML += "<td><input type='button' value='Borrar' onclick='tienda.delProducto(" + i + ")'></td>";
			tablaHTML += "</tr>";
		}
		tablaHTML += "</table>";
	} else {
		tablaHTML = "Tienda vacía";
	}

	document.getElementById('tienda').innerHTML = tablaHTML;
}

Tienda.prototype.cargaImagenes = function(nombre, opciones) {
	var elemento = document.getElementById(nombre);
	
	for(var i=0; i<opciones.length; i++) {
		var opcion = document.createElement('option');
		opcion.text = opciones[i];
		opcion.value = opciones[i];
		elemento.appendChild(opcion);
	}
}

//Definiendo Tienda
var Producto = function() {
	this._nombre = "";
	this._precio = 0;
	this._urlImagen = "";
	this._descripcion = "";
	this._datosCorrectos = false;
}

Producto.prototype.initProducto = function() {
	this._nombre = this.obtenValor("nombre");
	this._urlImagen = this.obtenValor("imagen");
	this._precio = this.obtenValor("precio");
	this._descripcion = this.obtenValor("notas");
	this.validaForma();
}

Producto.prototype.obtenValor = function(nombre) {
	var elemento = document.getElementById(nombre);
	return elemento.value;
}

Producto.prototype.limpiarValor = function(nombre) {
	var elemento = document.getElementById(nombre);
	elemento.value = "";
}

Producto.prototype.limpiarForma = function() {
	this.limpiarValor("nombre");
	this.limpiarValor("imagen");
	this.limpiarValor("precio");
	this.limpiarValor("notas");
}

Producto.prototype.validaForma = function() {
	var strErrores = "";
	this._datosCorrectos = false;
	
	if(this.obtenValor("nombre").trim() == "") strErrores += "Nombre ";
	if(this.obtenValor("imagen") == "Seleccione" || this.obtenValor("imagen") == "") strErrores += "URL ";
	if(isNaN(this.obtenValor("precio")) || this.obtenValor("precio").trim() == "") strErrores += "Precio numérico ";
	if(this.obtenValor("notas").trim() == "") strErrores += "Descripcion";

	if(strErrores != "") {
		alert("Ingrese: " + strErrores);
	} else {
		this._datosCorrectos = true;
	}
}

//Creando objeto tienda
var tienda = new Tienda();

window.onload = function() {
	tienda.cargaImagenes("imagen", ropa);
}