class Pagina {
	constructor(idApp) {
		this._idApp = idApp;
		this._flujo = null;
		this._usuario = null;
		this._rutas = [];
		this._id = "";
		this._url = "";
		this._esHome = false;

		this._cabecera = new Cabecera(this._idApp, "cabecera");
		this._contenido = new Contenido(this._idApp, "contenido");
		this._pie = new Pie(this._idApp, "pie");

		this._verEncabezado = true;
		this._verContenido = true;
		this._verPie = true;

		this._objsDisparadores = [];
	}

	pintar() {
		this._cabecera._rutas = this._rutas;
		this._cabecera._flujo = this._flujo;
		this._pie._usuario = this._usuario;
		if(this._verEncabezado) this._cabecera.pintar();
		if(this._verContenido) this._contenido.pintar();
		if(this._verPie) this._pie.pintar();
	}

	salir() {
		document.getElementById(this._id).innerHTML = "";
	}

	/*setDisparadores() {
		console.log("Disparadores " + this._rutas.length);
		for(let i=0; i<this._rutas.length; i++) {
			this._objsDisparadores.push(new Disparador(document.getElementById("btnOpc"+i), this._rutas[i]));
		}
	}*/
}

class Login extends Pagina {
	constructor(idApp) {
		super(idApp);
		this._verEncabezado = false;
		this._usuariosApi = new UsuariosApi();
	}

	pintar() {
		super.pintar();

		console.log(this._flujo);

		if(!document.getElementById(this._id)) {
			console.log("no esta" + this._id);
			let est = new Estructura();
			est.creaContenedor(this._id, this._contenido._idSeccion, "row");
		}

		document.getElementById(this._id).innerHTML = this.plantillaContenido();

		let forma = new Formulario();
		forma.creaInput("txtLUsuario", "userId", "form-control");
		forma.creaInput("txtLContrasenia", "passId", "form-control");
		forma.creaButton("btnLogin", "ingresoId", "btn btn-primary", "Ingresar");
		forma.creaButton("btnOpc0", "ingresoId", "btn btn-default", "Registrarse");

		document.getElementById("btnLogin").addEventListener("click", () => this.loguearUsuario());
		document.getElementById("btnOpc0").addEventListener("click", () => this._flujo.irURL(this._rutas[0]));
		//this.setDisparadores();
	}

	loguearUsuario() {
   		let usuario = new Usuario("", "", "", "", document.getElementById("txtLUsuario").value,
   								document.getElementById("txtLContrasenia").value);

		this._usuariosApi.loginDeUsuario(usuario).then(
			(data) => {
				if(data.message) {
					document.getElementById("mensajeId").innerHTML = data.message;
				} else {
					let usuario = this._usuariosApi.getUsuarioDeObjeto(data);
					usuario._password = document.getElementById("txtLContrasenia").value;
					this._usuariosApi.setUsuarioAtLocalStorage(usuario);
					this.salir();
					this._flujo.irHome();
				}
			}
		);
   	}

	plantillaContenido() {
		let resp = "";

		resp += "<div class='row'>";
		resp += "<div class='col-xs-12'>Titulo</div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-1'></div>";
		resp += "<div class='col-xs-4'>Información</div>";
		resp += "<div class='col-xs-6'>";
		resp += "<div class='panel panel-default'>";
		resp += "<div class='panel-heading'>";
		resp += "<h3 class='panel-title'>Ingreso a la App</h3>";
		resp += "</div>";
		resp += "<div class='panel-body'>";
		resp += "<div class='input-group' id='userId'>";
		resp += "<label>Usuario</label>";
		resp += "</div>";
		resp += "<div class='input-group' id='passId'>";
		resp += "<label>Contraseña</label>";
		resp += "</div>";
		resp += "<div class='input-group' id='mensajeId'>";
		resp += "</div>";
		resp += "<div class='input-group' id='ingresoId'>";
		resp += "</div>";
		resp += "</div>";
		resp += "</div>";
		resp += "</div>";
		resp += "<div class='col-xs-1'></div>";
		resp += "</div>";

		return resp;
	}
}

class Funcionalidad extends Pagina {
	constructor(idApp) {
		super(idApp);
	}
}

class Comidas extends Funcionalidad {
	constructor(idApp) {
		super(idApp);
		this._comidaApi = new ComidasApi();
	}

	pintar() {
		super.pintar();
   		//this.setDisparadores();

		this._comidaApi.getDeAlimentos().then(
			(data) => {
    			this.pintaDatos(data);
			}
		);
   	}

   	pintaDatos(arrayDeComidas) {
   		if(!document.getElementById(this._id)) {
			let est = new Estructura();
			est.creaContenedor(this._id, this._contenido._idSeccion, "row");
		}

   		let idContenedor = "listaComidas";
   		document.getElementById(this._id).innerHTML = this.pintaTabla(idContenedor);
   		this.pintarModal();

   		for(let i=0; i<arrayDeComidas.length; i++) {
   			let comida = arrayDeComidas[i];
   			comida.pintar(idContenedor);

   			document.getElementById("btnEdit" + comida._id).addEventListener("click", () => this.llenarModal(comida));
   			document.getElementById("btnElim" + comida._id).addEventListener("click", () => this.eliminarComida(comida));
   		}
   	}

   	pintarModal() {
		let forma = new Formulario();
		document.getElementById(this._id).innerHTML += this.plantillaEdicion();

		forma.creaInput("txtComNombre", "divbtnNombre", "form-control");
		forma.creaInput("txtComTipo", "divbtnTipo", "form-control");
		forma.creaInput("txtComPrecio", "divbtnPrecio", "form-control");
		forma.creaInput("txtComCalorias", "divbtnCalorias", "form-control");
		forma.creaInput("txtComExistencias", "divbtnExistencias", "form-control");
		forma.creaHidden("hidIDComida", "btnsModal");

		document.getElementById("btnComGuardar").addEventListener("click", () => this.guardarComida());
   	}

   	llenarModal(comida) {
   		if(comida) {
   			document.getElementById("txtComNombre").value = comida._nombre;
   			document.getElementById("txtComTipo").value = comida._tipo;
   			document.getElementById("txtComPrecio").value = comida._precio;
   			document.getElementById("txtComCalorias").value = comida._calorias;
   			document.getElementById("txtComExistencias").value = comida._existencias;
   			document.getElementById("hidIDComida").value = comida._id;
   		}
   	}

   	guardarComida() {
   		let comida = new Comida(document.getElementById("hidIDComida").value,
   								document.getElementById("txtComNombre").value,
   								document.getElementById("txtComPrecio").value,
   								document.getElementById("txtComCalorias").value,
   								document.getElementById("txtComExistencias").value,
   								document.getElementById("txtComTipo").value);

   		if(!comida._id) {
   			this._comidaApi.postDeAlimentos(comida).then(
   				(data) => {
    				this.pintar();
				}
   			);
   		} else {
   			this._comidaApi.putDeAlimentos(comida).then(
   				(data) => {
    				this.pintar();
				}
   			);
   		}
   	}

   	eliminarComida(comida) {
   		this._comidaApi.deleteDeAlimentos(comida._id).then(
   			(data) => {
    			this.pintar();
			}
   		);
   		this.pintar();
   	}

   	pintaTabla(id) {
		let sHtml = "";

		sHtml += "<div class='panel panel-default'>";
		sHtml += "<div class='row'><div class='col-md-2'>Nombre</div><div class='col-md-2'>Tipo</div><div class='col-md-2'>Precio</div><div class='col-md-2'>Calorias</div><div class='col-md-2'>Existencias</div><div class='col-md-2'>Acciones";
		sHtml += "<button type='button' class='btn btn-default' data-toggle='modal' data-target='#modalComida' id='btnAddComida'>+</button></div></div>";
		sHtml += "<div class='panel panel-default' id='" + id + "'></div>";

		return sHtml;
	}

	plantillaEdicion() {
		let resp = "";

		resp += "<div class='modal fade' id='modalComida' tabindex='-1' role='dialog' aria-labelledby='modalComidaLabel' aria-hidden='true'>";
		resp += "<div class='modal-dialog' role='document'>";
		resp += "<div class='modal-content'>";
		resp += "<div class='modal-header'>";
		resp += "<h5 class='modal-title' id='modalComidaLabel'>Editar Comida</h5>";
		resp += "<button type='button' class='close' data-dismiss='modal' aria-label='Close'>";
		resp += "<span aria-hidden='true'>&times;</span>";
		resp += "</button>";
		resp += "</div>";
		resp += "<div class='modal-body'>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Nombre</div>";
		resp += "<div class='col-xs-6' id='divbtnNombre'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Tipo</div>";
		resp += "<div class='col-xs-6' id='divbtnTipo'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Precio</div>";
		resp += "<div class='col-xs-6' id='divbtnPrecio'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Calorias</div>";
		resp += "<div class='col-xs-6' id='divbtnCalorias'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Existencias</div>";
		resp += "<div class='col-xs-6' id='divbtnExistencias'></div>";
		resp += "</div>";
		resp += "</div>";
		resp += "<div class='modal-footer' id='btnsModal'>";
		resp += "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Cerrar</button>";
		resp += "<button type='button' class='btn btn-primary' data-dismiss='modal' id='btnComGuardar'>Guardar Cambios</button>";
		resp += "</div>";
		resp += "</div>";
		resp += "</div>";
		resp += "</div>";

		return resp;
	}
}

class Bebidas extends Funcionalidad {
	constructor(idApp) {
		super(idApp);
		this._bebidasApi = new BebidasApi();
	}

	pintar() {
		super.pintar();
   		//this.setDisparadores();

		this._bebidasApi.getDeAlimentos().then(
			(data) => {
    			this.pintaDatos(data);
			}
		);
   	}

   	pintaDatos(arrayDeBebidas) {
   		if(!document.getElementById(this._id)) {
			let est = new Estructura();
			est.creaContenedor(this._id, this._contenido._idSeccion, "row");
		}

   		let idContenedor = "listaBebidas";
   		document.getElementById(this._id).innerHTML = this.pintaTabla(idContenedor);
   		this.pintarModal();

   		for(let i=0; i<arrayDeBebidas.length; i++) {
   			let bebida = arrayDeBebidas[i];
   			bebida.pintar(idContenedor);

   			document.getElementById("btnEdit" + bebida._id).addEventListener("click", () => this.llenarModal(bebida));
   			document.getElementById("btnElim" + bebida._id).addEventListener("click", () => this.eliminarBebida(bebida));
   		}
   	}

   	pintarModal() {
		let forma = new Formulario();
		document.getElementById(this._id).innerHTML += this.plantillaEdicion();

		forma.creaInput("txtBebNombre", "divbtnBNombre", "form-control");
		forma.creaInput("txtBebPrecio", "divbtnBPrecio", "form-control");
		forma.creaInput("txtBebCalorias", "divbtnBCalorias", "form-control");
		forma.creaInput("txtBebExistencias", "divbtnBExistencias", "form-control");
		forma.creaInput("txtBebGrado", "divbtnBGrado", "form-control");
		forma.creaHidden("hidIDBebida", "btnsBebModal");

		document.getElementById("btnBebGuardar").addEventListener("click", () => this.guardarBebida());
   	}

   	llenarModal(bebida) {
   		if(bebida) {
   			document.getElementById("txtBebNombre").value = bebida._nombre;
   			document.getElementById("txtBebPrecio").value = bebida._precio;
   			document.getElementById("txtBebCalorias").value = bebida._calorias;
   			document.getElementById("txtBebExistencias").value = bebida._existencias;
   			document.getElementById("txtBebGrado").value = bebida._gradoAlcohol;
   			document.getElementById("hidIDBebida").value = bebida._id;
   		}
   	}

   	guardarBebida() {
   		let bebida = new Bebida(document.getElementById("hidIDBebida").value,
   								document.getElementById("txtBebNombre").value,
   								document.getElementById("txtBebPrecio").value,
   								document.getElementById("txtBebCalorias").value,
   								document.getElementById("txtBebExistencias").value,
   								false,
   								document.getElementById("txtBebGrado").value);

   		if(!bebida._id) {
   			this._bebidasApi.postDeAlimentos(bebida).then(
   				(data) => {
    				this.pintar();
				}
   			);
   		} else {
   			this._bebidasApi.putDeAlimentos(bebida).then(
   				(data) => {
    				this.pintar();
				}
   			);
   		}
   	}

   	eliminarBebida(bebida) {
   		this._bebidasApi.deleteDeAlimentos(bebida._id).then(
   			(data) => {
    			this.pintar();
			}
   		);
   		this.pintar();
   	}

   	pintaTabla(id) {
		let sHtml = "";

		sHtml += "<div class='panel panel-default'>";
		sHtml += "<div class='row'><div class='col-md-2'>Nombre</div><div class='col-md-2'>Precio</div><div class='col-md-2'>Calorias</div><div class='col-md-2'>Existencias</div><div class='col-md-2'>Grado Alcóhol</div><div class='col-md-2'>Acciones";
		sHtml += "<button type='button' class='btn btn-default' data-toggle='modal' data-target='#modalBebida' id='btnAddBebida'>+</button></div></div>";
		sHtml += "<div class='panel panel-default' id='" + id + "'></div>";

		return sHtml;
	}

	plantillaEdicion() {
		let resp = "";

		resp += "<div class='modal fade' id='modalBebida' tabindex='-1' role='dialog' aria-labelledby='modalBebidaLabel' aria-hidden='true'>";
		resp += "<div class='modal-dialog' role='document'>";
		resp += "<div class='modal-content'>";
		resp += "<div class='modal-header'>";
		resp += "<h5 class='modal-title' id='modalBebidaLabel'>Editar Bebida</h5>";
		resp += "<button type='button' class='close' data-dismiss='modal' aria-label='Close'>";
		resp += "<span aria-hidden='true'>&times;</span>";
		resp += "</button>";
		resp += "</div>";
		resp += "<div class='modal-body'>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Nombre</div>";
		resp += "<div class='col-xs-6' id='divbtnBNombre'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Precio</div>";
		resp += "<div class='col-xs-6' id='divbtnBPrecio'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Calorias</div>";
		resp += "<div class='col-xs-6' id='divbtnBCalorias'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Existencias</div>";
		resp += "<div class='col-xs-6' id='divbtnBExistencias'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Grado Alcóhol</div>";
		resp += "<div class='col-xs-6' id='divbtnBGrado'></div>";
		resp += "</div>";
		resp += "</div>";
		resp += "<div class='modal-footer' id='btnsBebModal'>";
		resp += "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Cerrar</button>";
		resp += "<button type='button' class='btn btn-primary' data-dismiss='modal' id='btnBebGuardar'>Guardar Cambios</button>";
		resp += "</div>";
		resp += "</div>";
		resp += "</div>";
		resp += "</div>";

		return resp;
	}
}

class Usuarios extends Funcionalidad {
	constructor(idApp) {
		super(idApp);
		this._usuariosApi = new UsuariosApi();
	}

	pintar() {
		super.pintar();
   		//this.setDisparadores();

		this._usuariosApi.getDeUsuarios().then(
			(data) => {
    			this.pintaDatos(data);
			}
		);
   	}

   	pintaDatos(arrayDeUsuarios) {
   		let usuario;

   		if(!document.getElementById(this._id)) {
			let est = new Estructura();
			est.creaContenedor(this._id, this._contenido._idSeccion, "row");
		}

		document.getElementById(this._id).innerHTML = "";

   		for(let i=0; i<arrayDeUsuarios.length; i++) {
   			if(!usuario && arrayDeUsuarios[i]._usuario == this._usuario._usuario) {
   				usuario = arrayDeUsuarios[i];
   			}
   		}

   		this.pintarForma(usuario);
   	}

   	pintarForma(usuario) {
   		let idContenedor = "perfilUsuario";
   		let forma = new Formulario();
		document.getElementById(this._id).innerHTML += this.plantillaEdicion(idContenedor);

		forma.creaInput("txtNombre", "divtxtNombre", "form-control");
		forma.creaInput("txtApellidos", "divtxtApellidos", "form-control");
		forma.creaInput("txtEmail", "divtxtEmail", "form-control");
		forma.creaInput("txtUsuario", "divtxtUsuario", "form-control");
		forma.creaHidden("txtIDUsuario", "divbtnUsuGuardar");
		forma.creaButton("btnUsuGuardar", "divbtnUsuGuardar", "btn btn-default", "Guardar Cambios");
		forma.creaButton("btnUsuEliminar", "divbtnUsuGuardar", "btn btn-default", "Eliminar Usuario");

		document.getElementById("btnUsuGuardar").addEventListener("click", () => this.guardarUsuario());
		document.getElementById("btnUsuEliminar").addEventListener("click", () => this.eliminarUsuario());

		this.llenarForma(usuario);
   	}

   	llenarForma(usuario) {
   		if(usuario) {
   			document.getElementById("txtIDUsuario").value = usuario._id;
   			document.getElementById("txtNombre").value = usuario._nombre;
   			document.getElementById("txtApellidos").value = usuario._apellidos;
   			document.getElementById("txtEmail").value = usuario._email;
   			document.getElementById("txtUsuario").value = usuario._usuario;
   		}
   	}

   	guardarUsuario() {
   		let usuario = new Usuario(
   								document.getElementById("txtIDUsuario").value,
   								document.getElementById("txtNombre").value,
   								document.getElementById("txtApellidos").value,
   								document.getElementById("txtEmail").value,
   								document.getElementById("txtUsuario").value,
   								this._usuario._password);

		this._usuariosApi.putDeUsuarios(usuario).then(
			(data) => {
				alert("Informacion actualizada!");
				this.pintar();
			}
		);
   	}

   	eliminarUsuario() {
   		this._usuariosApi.deleteDeUsuarios(this._usuario).then(
   			(data) => {
   				alert("Usuario eliminado!");
    			this.pintar();
    			this._usuariosApi.setLimpiarSesion(usuario);
			}
   		);
   	}

   	plantillaEdicion(id) {
		let resp = "";

		resp += "<div class='panel panel-default' id='" + id + "'>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Nombre</div>";
		resp += "<div class='col-xs-6' id='divtxtNombre'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Apellidos</div>";
		resp += "<div class='col-xs-6' id='divtxtApellidos'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Email</div>";
		resp += "<div class='col-xs-6' id='divtxtEmail'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Usuario</div>";
		resp += "<div class='col-xs-6' id='divtxtUsuario'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-12' id='divbtnUsuGuardar'></div>";
		resp += "</div>";
		resp += "</div>";

		return resp;
	}
}

class Registro extends Funcionalidad {
	constructor(idApp) {
		super(idApp);
		this._verEncabezado = false;
		this._usuariosApi = new UsuariosApi();
	}

   	pintar() {
   		super.pintar();
   		if(!document.getElementById(this._id)) {
			let est = new Estructura();
			est.creaContenedor(this._id, this._contenido._idSeccion, "row");
		}

   		let idContenedor = "registroUsuario";
   		let forma = new Formulario();
		document.getElementById(this._id).innerHTML = this.plantillaEdicion(idContenedor);

		forma.creaInput("txtRNombre", "divtxtRNombre", "form-control");
		forma.creaInput("txtRApellidos", "divtxtRApellidos", "form-control");
		forma.creaInput("txtREmail", "divtxtREmail", "form-control");
		forma.creaInput("txtRUsuario", "divtxtRUsuario", "form-control");
		forma.creaInput("txtRPassword", "divtxtRPassword", "form-control");
		forma.creaButton("btnRUsuGuardar", "divbtnRUsuGuardar", "btn btn-primary", "Guardar Cambios");
		forma.creaButton("btnOpc0", "divbtnRUsuGuardar", "btn btn-default", "Cancelar");

		document.getElementById("btnRUsuGuardar").addEventListener("click", () => this.guardarUsuario());
		document.getElementById("btnOpc0").addEventListener("click", () => this._flujo.irURL(this._rutas[0]));
		//this.setDisparadores();
   	}

   	guardarUsuario() {
   		let usuario = new Usuario("",
   								document.getElementById("txtRNombre").value,
   								document.getElementById("txtRApellidos").value,
   								document.getElementById("txtREmail").value,
   								document.getElementById("txtRUsuario").value,
   								document.getElementById("txtRPassword").value);

		this._usuariosApi.postDeUsuarios(usuario).then(
			(data) => {
				this.pintar();
				document.getElementById("btnOpc0").innerHTML = "Ir a Login";
				document.getElementById("btnOpc0").className = "btn btn-primary";
				document.getElementById("divbtnRUsuGuardar").removeChild(document.getElementById("btnRUsuGuardar"));
			alert("Registro exitoso, favor de ir a Login!");
			}
		);
   	}

   	plantillaEdicion(id) {
		let resp = "";

		resp += "<div class='panel panel-default' id='" + id + "'>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Nombre</div>";
		resp += "<div class='col-xs-6' id='divtxtRNombre'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Apellidos</div>";
		resp += "<div class='col-xs-6' id='divtxtRApellidos'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Email</div>";
		resp += "<div class='col-xs-6' id='divtxtREmail'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Usuario</div>";
		resp += "<div class='col-xs-6' id='divtxtRUsuario'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Contraseña</div>";
		resp += "<div class='col-xs-6' id='divtxtRPassword'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-12' id='divbtnRUsuGuardar'></div>";
		resp += "</div>";
		resp += "</div>";

		return resp;
	}
}

class Home extends Funcionalidad {
   	pintar() {
   		super.pintar();

   		console.log("home" + this._flujo);

   		if(!document.getElementById(this._id)) {
			let est = new Estructura();
			est.creaContenedor(this._id, this._contenido._idSeccion, "row");
		}

		document.getElementById(this._id).innerHTML = "Bienvenido a la App";

		//this.setDisparadores();
   	}
}

class Seccion {
	constructor(idApp, idSeccion) {
		this._idApp = idApp;
		this._idSeccion = idSeccion;
	}

	pintar() {}
	refrescar() {}
}

class Cabecera extends Seccion {
	constructor(idApp, idSeccion) {
		super(idApp, idSeccion);
		this._rutas = [];
		this._flujo = null;
	}

	pintar() {
		let sHtml = "";

		if(!document.getElementById(this._idSeccion)) {
			let est = new Estructura();
			est.creaContenedor(this._idSeccion, this._idApp, "contenedorCabecera");
		}

		console.log("rutas cabecera " + this._rutas.length)

		for(let i=0; i<this._rutas.length; i++) {
			if(i==0) {
				sHtml += "<button type='button' class='btn btn-primary navbar-btn' id='btnOpc" + i + "'>" + this._rutas[i] + "</button>";
			} else {
				sHtml += "<button type='button' class='btn btn-default navbar-btn' id='btnOpc" + i + "'>" + this._rutas[i] + "</button>";
			}
		}

		document.getElementById(this._idSeccion).innerHTML = sHtml;

		for(let i=0; i<this._rutas.length; i++) {
			document.getElementById("btnOpc" + i).addEventListener("click", () => this._flujo.irURL(this._rutas[i]));
		}
	}
}

class Contenido extends Seccion {
	pintar() {
		if(!document.getElementById(this._idSeccion)) {
			let est = new Estructura();
			est.creaContenedor(this._idSeccion, this._idApp, "contenedorContenido");
		}
	}
}

class Pie extends Seccion {
	constructor(idApp, idSeccion) {
		super(idApp, idSeccion);
		this._usuario = null;
	}

	pintar() {
		let est = new Estructura();
		
		if(!document.getElementById(this._idSeccion)) {
			est.creaContenedor(this._idSeccion, this._idApp, "contenedorPie");
		}

		document.getElementById(this._idSeccion).innerText = "";
		
		est.creaContenedor("pie", this._idSeccion, "row");
		est.creaContenedor("pie1", "pie", "col-xs-6 pie");
		est.creaContenedor("pie2", "pie", "col-xs-6 pie");
		document.getElementById("pie1").innerHTML = "2017";

		if(this._usuario) {
			document.getElementById("pie2").innerHTML = this._usuario._apellidos + "," + this._usuario._nombre;
		}
	}
}