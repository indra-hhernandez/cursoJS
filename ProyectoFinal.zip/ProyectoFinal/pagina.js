class Pagina {
	constructor(idApp) {
		this._idApp = idApp;
		this._id = "";
		this._url = "";
		this._usuario = "";

		this._cabecera = new Cabecera(this._idApp, "cabecera");
		this._contenido = new Contenido(this._idApp, "contenido");
		this._pie = new Pie(this._idApp, "pie");

		this._verEncabezado = true;
		this._verContenido = true;
		this._verPie = true;

		this._objsAccionSiguiente = [];
		this._objsAccionAnterior = [];
	}

	pintar() {
		if(this._verEncabezado) this._cabecera.pintar();
		if(this._verContenido) this._contenido.pintar();
		if(this._verPie) this._pie.pintar();
	}

	validar() {
		return true;
	}

	avisoRetroceso() {
		return true;
	}

	salir() {
		document.getElementById(this._id).style.display = "none";
	}
}

class Login extends Pagina {
	constructor(cabecera, contenido, pie) {
		super(cabecera, contenido, pie);
		this._verEncabezado = false;
		this._id = "login";
		this._url = "/login";
	}

	pintar() {
		super.pintar();
		if(!document.getElementById(this._id)) {
			let est = new Estructura();
			est.creaContenedor(this._id, this._contenido._idSeccion, "row");
			document.getElementById(this._id).innerHTML = this.plantillaContenido();

			let forma = new Formulario();
			forma.creaInput("txtUsuario", "userId", "form-control");
			forma.creaInput("txtContrasenia", "passId", "form-control");
			forma.creaButton("btnLogin", "ingresoId", "btn btn-default", "Ingresar");

			this._objsAccionSiguiente.push(document.getElementById("btnLogin"));
		}
	}

	plantillaContenido() {
		let resp = "";

		resp += "<div class='row'>";
		resp += "<div class='col-xs-12'>Titulo</div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-1'></div>";
		resp += "<div class='col-xs-4'>Información</div>";
		resp += "<div class='col-xs-6'>";
		resp += "<div class='panel panel-default'>";
		resp += "<div class='panel-heading'>";
		resp += "<h3 class='panel-title'>Ingreso a la App</h3>";
		resp += "</div>";
		resp += "<div class='panel-body'>";
		resp += "<div class='input-group' id='userId'>";
		resp += "<label>Usuario</label>";
		resp += "</div>";
		resp += "<div class='input-group' id='passId'>";
		resp += "<label>Contraseña</label>";
		resp += "</div>";
		resp += "<div 	class='input-group' id='olvidoId'>";
		resp += "</div>";
		resp += "<div class='input-group' id='ingresoId'>";
		resp += "</div>";
		resp += "</div>";
		resp += "</div>";
		resp += "</div>";
		resp += "<div class='col-xs-1'></div>";
		resp += "</div>";

		return resp;
	}
}

class Funcionalidad extends Pagina {
	constructor(cabecera, contenido, pie) {
		super(cabecera, contenido, pie);
	}
}

class Comidas extends Funcionalidad {
	constructor(cabecera, contenido, pie) {
		super(cabecera, contenido, pie);
		this._id = "comidas";
		this._url = "/comidas";
		this._comidaApi = new ComidasApi();
	}

	pintar() {
		this._comidaApi.getDeAlimentos().then(
			(data) => {
    			this.pintaDatos(data);
			}
		);
   	}

   	pintaDatos(arrayDeComidas) {
   		super.pintar();

   		if(!document.getElementById(this._id)) {
			console.log("crea principal");
			let est = new Estructura();
			est.creaContenedor(this._id, this._contenido._idSeccion, "row");
		}

   		let idContenedor = "listaComidas";
   		document.getElementById(this._id).innerHTML = this.pintaTabla(idContenedor);
   		this.pintarModal();

   		for(let i=0; i<arrayDeComidas.length; i++) {
   			let comida = arrayDeComidas[i];
   			comida.pintar(idContenedor);

   			document.getElementById("btnEdit" + comida._id).addEventListener("click", () => this.llenarModal(comida));
   			document.getElementById("btnElim" + comida._id).addEventListener("click", () => this.eliminarComida(comida));
   		}
   	}

   	pintarModal() {
		let forma = new Formulario();
		document.getElementById(this._id).innerHTML += this.plantillaEdicion();

		forma.creaInput("txtComNombre", "divbtnNombre", "form-control");
		forma.creaInput("txtComTipo", "divbtnTipo", "form-control");
		forma.creaInput("txtComPrecio", "divbtnPrecio", "form-control");
		forma.creaInput("txtComCalorias", "divbtnCalorias", "form-control");
		forma.creaInput("txtComExistencias", "divbtnExistencias", "form-control");
		forma.creaHidden("hidIDComida", "btnsModal");

		document.getElementById("btnComGuardar").addEventListener("click", () => this.guardarComida());
   	}

   	llenarModal(comida) {
   		if(comida) {
   			document.getElementById("txtComNombre").value = comida._nombre;
   			document.getElementById("txtComTipo").value = comida._tipo
   			document.getElementById("txtComPrecio").value = comida._precio;
   			document.getElementById("txtComCalorias").value = comida._calorias;
   			document.getElementById("txtComExistencias").value = comida._existencias;
   			document.getElementById("hidIDComida").value = comida._id;
   		}
   	}

   	guardarComida() {
   		let comida = new Comida(document.getElementById("hidIDComida").value,
   								document.getElementById("txtComNombre").value,
   								document.getElementById("txtComPrecio").value,
   								document.getElementById("txtComCalorias").value,
   								document.getElementById("txtComExistencias").value,
   								document.getElementById("txtComTipo").value);

   		if(!comida._id) {
   			console.log("post" + comida._id);
   			this._comidaApi.postDeAlimentos(comida).then(
   				(data) => {
   					console.log(data);
    				this.pintar();
				}
   			);
   		} else {
   			console.log("put" + comida._id);
   			this._comidaApi.putDeAlimentos(comida).then(
   				(data) => {
   					console.log(data);
    				this.pintar();
				}
   			);
   		}
   	}

   	eliminarComida(comida) {
   		this._comidaApi.deleteDeAlimentos(comida._id).then(
   			(data) => {
   				console.log(data);
    			this.pintar();
			}
   		);
   		this.pintar();
   	}

   	pintaTabla(id) {
		let sHtml = "";

		sHtml += "<div class='panel panel-default'>";
		sHtml += "<div class='row'><div class='col-md-2'>Nombre</div><div class='col-md-2'>Tipo</div><div class='col-md-2'>Precio</div><div class='col-md-2'>Calorias</div><div class='col-md-2'>Existencias</div><div class='col-md-2'>Acciones";
		sHtml += "<button type='button' class='btn btn-default' data-toggle='modal' data-target='#modalComida' id='btnAddComida'>+</button></div></div>";
		sHtml += "<div class='panel panel-default' id='" + id + "'></div>";

		return sHtml;
	}

	plantillaEdicion() {
		let resp = "";

		resp += "<div class='modal fade' id='modalComida' tabindex='-1' role='dialog' aria-labelledby='modalComidaLabel' aria-hidden='true'>";
		resp += "<div class='modal-dialog' role='document'>";
		resp += "<div class='modal-content'>";
		resp += "<div class='modal-header'>";
		resp += "<h5 class='modal-title' id='modalComidaLabel'>Editar Comida</h5>";
		resp += "<button type='button' class='close' data-dismiss='modal' aria-label='Close'>";
		resp += "<span aria-hidden='true'>&times;</span>";
		resp += "</button>";
		resp += "</div>";
		resp += "<div class='modal-body'>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Nombre</div>";
		resp += "<div class='col-xs-6' id='divbtnNombre'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Tipo</div>";
		resp += "<div class='col-xs-6' id='divbtnTipo'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Precio</div>";
		resp += "<div class='col-xs-6' id='divbtnPrecio'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Calorias</div>";
		resp += "<div class='col-xs-6' id='divbtnCalorias'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Existencias</div>";
		resp += "<div class='col-xs-6' id='divbtnExistencias'></div>";
		resp += "</div>";
		resp += "</div>";
		resp += "<div class='modal-footer' id='btnsModal'>";
		resp += "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Cerrar</button>";
		resp += "<button type='button' class='btn btn-primary' data-dismiss='modal' id='btnComGuardar'>Guardar Cambios</button>";
		resp += "</div>";
		resp += "</div>";
		resp += "</div>";
		resp += "</div>";

		return resp;
	}
}

class Bebidas extends Funcionalidad {
	constructor(cabecera, contenido, pie) {
		super(cabecera, contenido, pie);
		this._id = "bebidas";
		this._url = "/bebidas";
		this._bebidasApi = new BebidasApi();
	}

	pintar() {
		this._bebidasApi.getDeAlimentos().then(
			(data) => {
    			this.pintaDatos(data);
			}
		);
   	}

   	pintaDatos(arrayDeBebidas) {
   		super.pintar();

   		if(!document.getElementById(this._id)) {
			let est = new Estructura();
			est.creaContenedor(this._id, this._contenido._idSeccion, "row");
		}

   		let idContenedor = "listaBebidas";
   		document.getElementById(this._id).innerHTML = this.pintaTabla(idContenedor);
   		this.pintarModal();

   		for(let i=0; i<arrayDeBebidas.length; i++) {
   			let bebida = arrayDeBebidas[i];
   			bebida.pintar(idContenedor);

   			document.getElementById("btnEdit" + bebida._id).addEventListener("click", () => this.llenarModal(bebida));
   			document.getElementById("btnElim" + bebida._id).addEventListener("click", () => this.eliminarBebida(bebida));
   		}
   	}

   	pintarModal() {
		let forma = new Formulario();
		document.getElementById(this._id).innerHTML += this.plantillaEdicion();

		forma.creaInput("txtBebNombre", "divbtnBNombre", "form-control");
		forma.creaInput("txtBebPrecio", "divbtnBPrecio", "form-control");
		forma.creaInput("txtBebCalorias", "divbtnBCalorias", "form-control");
		forma.creaInput("txtBebExistencias", "divbtnBExistencias", "form-control");
		forma.creaInput("txtBebGrado", "divbtnBGrado", "form-control");
		forma.creaHidden("hidIDBebida", "btnsBebModal");

		document.getElementById("btnBebGuardar").addEventListener("click", () => this.guardarBebida());
   	}

   	llenarModal(bebida) {
   		if(bebida) {
   			document.getElementById("txtBebNombre").value = bebida._nombre;
   			document.getElementById("txtBebPrecio").value = bebida._precio;
   			document.getElementById("txtBebCalorias").value = bebida._calorias;
   			document.getElementById("txtBebExistencias").value = bebida._existencias;
   			document.getElementById("txtBebGrado").value = bebida._gradoAlcohol;
   			document.getElementById("hidIDBebida").value = bebida._id;
   		}
   	}

   	guardarBebida() {
   		let bebida = new Bebida(document.getElementById("hidIDBebida").value,
   								document.getElementById("txtBebNombre").value,
   								document.getElementById("txtBebPrecio").value,
   								document.getElementById("txtBebCalorias").value,
   								document.getElementById("txtBebExistencias").value,
   								false,
   								document.getElementById("txtBebGrado").value);

   		if(!bebida._id) {
   			console.log("post" + bebida._id);
   			this._bebidasApi.postDeAlimentos(bebida).then(
   				(data) => {
   					console.log(data);
    				this.pintar();
				}
   			);
   		} else {
   			console.log("put" + bebida._id);
   			this._bebidasApi.putDeAlimentos(bebida).then(
   				(data) => {
   					console.log(data);
    				this.pintar();
				}
   			);
   		}
   	}

   	eliminarBebida(bebida) {
   		this._bebidasApi.deleteDeAlimentos(bebida._id).then(
   			(data) => {
   				console.log(data);
    			this.pintar();
			}
   		);
   		this.pintar();
   	}

   	pintaTabla(id) {
		let sHtml = "";

		sHtml += "<div class='panel panel-default'>";
		sHtml += "<div class='row'><div class='col-md-2'>Nombre</div><div class='col-md-2'>Precio</div><div class='col-md-2'>Calorias</div><div class='col-md-2'>Existencias</div><div class='col-md-2'>Grado Alcóhol</div><div class='col-md-2'>Acciones";
		sHtml += "<button type='button' class='btn btn-default' data-toggle='modal' data-target='#modalBebida' id='btnAddBebida'>+</button></div></div>";
		sHtml += "<div class='panel panel-default' id='" + id + "'></div>";

		return sHtml;
	}

	plantillaEdicion() {
		let resp = "";

		resp += "<div class='modal fade' id='modalBebida' tabindex='-1' role='dialog' aria-labelledby='modalBebidaLabel' aria-hidden='true'>";
		resp += "<div class='modal-dialog' role='document'>";
		resp += "<div class='modal-content'>";
		resp += "<div class='modal-header'>";
		resp += "<h5 class='modal-title' id='modalBebidaLabel'>Editar Bebida</h5>";
		resp += "<button type='button' class='close' data-dismiss='modal' aria-label='Close'>";
		resp += "<span aria-hidden='true'>&times;</span>";
		resp += "</button>";
		resp += "</div>";
		resp += "<div class='modal-body'>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Nombre</div>";
		resp += "<div class='col-xs-6' id='divbtnBNombre'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Precio</div>";
		resp += "<div class='col-xs-6' id='divbtnBPrecio'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Calorias</div>";
		resp += "<div class='col-xs-6' id='divbtnBCalorias'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Existencias</div>";
		resp += "<div class='col-xs-6' id='divbtnBExistencias'></div>";
		resp += "</div>";
		resp += "<div class='row'>";
		resp += "<div class='col-xs-6'>Grado Alcóhol</div>";
		resp += "<div class='col-xs-6' id='divbtnBGrado'></div>";
		resp += "</div>";
		resp += "</div>";
		resp += "<div class='modal-footer' id='btnsBebModal'>";
		resp += "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Cerrar</button>";
		resp += "<button type='button' class='btn btn-primary' data-dismiss='modal' id='btnBebGuardar'>Guardar Cambios</button>";
		resp += "</div>";
		resp += "</div>";
		resp += "</div>";
		resp += "</div>";

		return resp;
	}
}

class Usuarios extends Funcionalidad {
	constructor(cabecera, contenido, pie) {
		super(cabecera, contenido, pie);
		this._id = "usuarios";
		this._url = "/usuarios";
	}

	pintar() {
		super.pintar();
		if(!document.getElementById(this._id)) {
			let est = new Estructura();
			est.creaContenedor(this._id, this._contenido._idSeccion, "row");
			let forma = new Formulario();
			forma.creaButton("AteriorX3", this._id, "", "Anterior");
			forma.creaButton("SiguienteX3", this._id, "", "Siguiente");

			this._objsAccionSiguiente.push(document.getElementById("SiguienteX3"));
			this._objsAccionAnterior.push(document.getElementById("AteriorX3"));
		} else {
			document.getElementById(this._id).style.display = "";
		}
	}
}

class x4 extends Funcionalidad {
	constructor(cabecera, contenido, pie) {
		super(cabecera, contenido, pie);
		this._id = "x4";
		this._url = "/x4";
	}

	pintar() {
		super.pintar();
		if(!document.getElementById(this._id)) {
			let est = new Estructura();
			est.creaContenedor(this._id, this._contenido._idSeccion, "row");
			let forma = new Formulario();
			forma.creaButton("AteriorX4", this._id, "", "Anterior");
			forma.creaButton("SiguienteX4", this._id, "", "Siguiente");

			this._objsAccionSiguiente.push(document.getElementById("SiguienteX4"));
			this._objsAccionAnterior.push(document.getElementById("AteriorX4"));
		} else {
			document.getElementById(this._id).style.display = "";
		}
	}
}

class Seccion {
	constructor(idApp, idSeccion) {
		this._idApp = idApp;
		this._idSeccion = idSeccion;
	}

	pintar() {}
	refrescar() {}
}

class Cabecera extends Seccion {
	pintar() {
		if(!document.getElementById(this._idSeccion)) {
			let est = new Estructura();
			est.creaContenedor(this._idSeccion, this._idApp, "contenedorCabecera");
			est.creaContenedor("menu", this._idSeccion, "row");
			est.creaContenedor("opciones", "menu", "col-xs-1 cabecera");
			est.creaContenedor("opc1", "menu", "col-xs-2 cabecera");
			est.creaContenedor("opc2", "menu", "col-xs-2 cabecera");
			est.creaContenedor("opc3", "menu", "col-xs-2 cabecera");
			est.creaContenedor("opc4", "menu", "col-xs-2 cabecera");
			est.creaContenedor("nav", "menu", "col-xs-3 cabecera");
		}
	}
}

class Contenido extends Seccion {
	pintar() {
		if(!document.getElementById(this._idSeccion)) {
			let est = new Estructura();
			est.creaContenedor(this._idSeccion, this._idApp, "contenedorContenido");
		}
	}
}

class Pie extends Seccion {
	pintar() {
		if(!document.getElementById(this._idSeccion)) {
			let est = new Estructura();
			est.creaContenedor(this._idSeccion, this._idApp, "contenedorPie");
			est.creaContenedor("pie", this._idSeccion, "row");
			est.creaContenedor("pie1", "pie", "col-xs-12 pie");
			document.getElementById("pie1").innerHTML = "2017";
		}
	}
}

class Opcion {}
class Lista {}
class Detalle {}

