class Cargando() {
	constructor() {
		
	}
}