/*Header
	Control de Flujo
		Navegacion
	Content
		Secciones
	Footer
		Firma
*/

class Aplicacion {
	constructor() {
		this._id = "xText";
		this._paginas = [new Login(this._id), new Comidas(this._id), new Bebidas(this._id), new x3(this._id), new x4(this._id)];
		this._paginaHome = 1;
		this._flujo = new Flujo(this._id, this._paginas, this._paginaHome);
	}

	iniciar() {
		let elemento = document.createElement("DIV");
		elemento.innerHTML = "<div id='" + this._id + "' class='container'></div>";
		document.body.appendChild(elemento);
		this._flujo.iniciar();
	}
}	

class Flujo {
	constructor(idApp, paginas, idxHome) {
		this._idApp = idApp;
		this._paginas = paginas;
		this._paginaHome = this._paginas[idxHome];
		this._paginaActual = this._paginas[2];
		this._estado = 0;
	}

	iniciar() {
		this.presentarPagina();
	}

	presentarPagina() {
		this._paginaActual.pintar();
		this.setDisparadores();
	}

	pasoSiguiente() {
		if(this._paginaActual.validar()) {
			let indice = this._paginas.indexOf(this._paginaActual);
			this._paginaActual.salir();

			if(indice < this._paginas.length-1) {
				this._paginaActual = this._paginas[indice+1];
			} else {
				this._paginaActual = this._paginas[0];
			}

			this.presentarPagina();
		}
	}

	pasoAnterior() {
		if(this._paginaActual.avisoRetroceso()) {
			let indice = this._paginas.indexOf(this._paginaActual);
			this._paginaActual.salir();

			if(indice > 0) {
				this._paginaActual = this._paginas[indice-1];
			}

			this.presentarPagina();
		}
	}

	irHome() {
		this._paginaActual = this._paginaHome;
		this.presentarPagina();
	}

	irURL(url) {
		let paginaDestino;

		for(let i=0; i<this._paginas.length; i++) {
			if(!paginaDestino && url == this._paginas[i]._url) {
				paginaDestino = this._paginas[i];
			}
		}

		if(!paginaDestino) {
			this._paginaActual = paginaDestino;
			this.presentarPagina();
		} else {
			alert("Página no existe");
		}
	}

	setDisparadores() {
		for(let i=0; i<this._paginaActual._objsAccionSiguiente.length; i++) {
			let objDisparador = this._paginaActual._objsAccionSiguiente[i];
			objDisparador.addEventListener("click", () => this.pasoSiguiente());
		}

		for(let i=0; i<this._paginaActual._objsAccionAnterior.length; i++) {
			let objDisparador = this._paginaActual._objsAccionAnterior[i];
			objDisparador.addEventListener("click", () => this.pasoAnterior());
		}
	}

	getUsuarioFormLocalStorage() {
		let usuario = localStorage.getItem("usuario");
		console.log(usuario);
	}

	setUsuarioFormLocalStorage(usuario) {
		localStorage.setItem("usuario", usuario);
	}
}

class ApiClient {
	constructor() {
	}

	get(url) {
		let cabeceras = new Headers();
		let init = {
			method: 'GET',
			headers: cabeceras
		};

		let promise = fetch(url, init).then(
			(response) => {
				return response.json();
			}
		);

		return promise;
	}

	post(url, params) {
		let cabeceras = new Headers();
		cabeceras.append('Content-Type', 'application/json');

		console.log(JSON.stringify(params));

		let init = {
			method: 'POST',
			headers: cabeceras,
			body: JSON.stringify(params)
		};

		let promise = fetch(url, init).then(
			(response) => {
				return response.json();
			}
		);

		return promise;
	}

	del(url) {
		let cabeceras = new Headers();

		let init = {
			method: 'DELETE',
			headers: cabeceras,
		};

		let promise = fetch(url, init).then(
			(response) => {
				return response.json();
			}
		);

		return promise;
	}

	put(url, params) {
		let cabeceras = new Headers();
		cabeceras.append('Content-Type', 'application/json');

		console.log(JSON.stringify(params));

		let init = {
			method: 'PUT',
			headers: cabeceras,
			body: JSON.stringify(params)
		};

		let promise = fetch(url, init).then(
			(response) => {
				return response.json();
			}
		);

		return promise;
	}
}

class AlimentosApi {
	constructor() {
		this._urlBase = "http://104.236.5.232/api";
		this._apiClient = new ApiClient();
		this._url = "";
	}

	getDeAlimentos() {
		let urlCompleta = this._urlBase + this._url;
		let promise = this._apiClient.get(urlCompleta).then(
			(respuesta) => {
				let arrayAlimentos = [];

				for(let i=0; i<respuesta.length; i++) {
					arrayAlimentos.push(this.getAlimentoDeObjeto(respuesta[i]));
				}

				return arrayAlimentos;
			}
		);

		return promise;
	}

	postDeAlimentos(alimento) {
		let urlCompleta = this._urlBase + this._url;
		let params = this.armaParametros(alimento);
		let promise = this._apiClient.post(urlCompleta, params).then(
			(respuesta) => {
				return respuesta;
			}
		);

		return promise;
	}

	deleteDeAlimentos(id) {
		let urlCompleta = this._urlBase + this._url + "/" + id;

		let promise = this._apiClient.del(urlCompleta).then(
			(respuesta) => {
				return respuesta;
			}
		);

		return promise;
	}

	putDeAlimentos(alimento) {
		let urlCompleta = this._urlBase + this._url + "/" + alimento._id;
		let params = this.armaParametros(alimento);
		let promise = this._apiClient.put(urlCompleta, params).then(
			(respuesta) => {
				return respuesta;
			}
		);

		return promise;
	}

	armaParametros(alimento) {}
	getAlimentoDeObjeto(objeto) {}
}

class ComidasApi extends AlimentosApi {
	constructor() {
		super();
		this._url = "/comidas";
	}

	armaParametros(comida) {
		return {
			tipo: comida._tipo,
	        precio: Number(comida._precio),
	        calorias: Number(comida._calorias),
	        existencias: Number(comida._existencias),
	        nombre: comida._nombre
		}
	}

	getAlimentoDeObjeto(objeto) {
		return new Comida(objeto._id, objeto.nombre, objeto.precio, objeto.calorias, objeto.existencias, objeto.tipo);
	}
}

class BebidasApi extends AlimentosApi {
	constructor() {
		super();
		this._url = "/bebidas";
	}

	armaParametros(bebida) {
		return {
			grados: bebida._gradoAlcohol,
			esAlcoholica: bebida._esAlcoholica,
			precio: bebida._precio,
			calorias: bebida._calorias,
			existencias: bebida._existencias,
			nombre: bebida._nombre
		}
	}

	getAlimentoDeObjeto(objeto) {
		return new Bebida(objeto._id, objeto.nombre, objeto.precio, objeto.calorias, objeto.existencias, objeto.esAlcoholica, objeto.grados);
	}
}

class Sesion {
	constructor() {
		this._usuario = "";
		this._sesionId = "";
	}
}

class Alimento {
	constructor(id, nombre, precio, calorias, existencias) {
		this._id = id;
		this._nombre = nombre;
		this._precio = precio;
		this._calorias = calorias;
		this._existencias = existencias;
	}
}

class Comida extends Alimento {
	constructor(id, nombre, precio, calorias, existencias, tipo) {
		super(id, nombre, precio, calorias, existencias);
		this._tipo = tipo;
	}

	pintar(idContenedor) {
		let sId = "item" + this._id;
		let est = new Estructura();
		let forma = new Formulario();

		est.creaContenedor(sId, idContenedor, "row");
		est.creaContenedorTexto("", sId, "col-md-2", this._nombre);
		est.creaContenedorTexto("", sId, "col-md-2", this._tipo);
		est.creaContenedorTexto("", sId, "col-md-2", this._precio);
		est.creaContenedorTexto("", sId, "col-md-2", this._calorias);
		est.creaContenedorTexto("", sId, "col-md-2", this._existencias);
		est.creaContenedor("control" + this._id, sId, "col-md-2");
		document.getElementById("control" + this._id).innerHTML = "<button type='button' class='btn btn-default' data-toggle='modal' data-target='#modalComida' id='btnEdit" + this._id + "'>Editar</button>";
		forma.creaButton("btnElim" + this._id, "control" + this._id, "btn button-default", "-");
	}
}

class Bebida extends Alimento {
	constructor(id, nombre, precio, calorias, existencias, esAlcoholica, gradoAlcohol) {
		super(id, nombre, precio, calorias, existencias);
		this._esAlcoholica = (gradoAlcohol > 0);
		this._gradoAlcohol = gradoAlcohol;
	}

	pintar(idContenedor) {
		let sId = "item" + this._id;
		let est = new Estructura();
		let forma = new Formulario();

		est.creaContenedor(sId, idContenedor, "row");
		est.creaContenedorTexto("", sId, "col-md-2", this._nombre);
		est.creaContenedorTexto("", sId, "col-md-2", this._precio);
		est.creaContenedorTexto("", sId, "col-md-2", this._calorias);
		est.creaContenedorTexto("", sId, "col-md-2", this._existencias);
		est.creaContenedorTexto("", sId, "col-md-2", this._gradoAlcohol);
		est.creaContenedor("control" + this._id, sId, "col-md-2");
		document.getElementById("control" + this._id).innerHTML = "<button type='button' class='btn btn-default' data-toggle='modal' data-target='#modalBebida' id='btnEdit" + this._id + "'>Editar</button>";
		forma.creaButton("btnElim" + this._id, "control" + this._id, "btn button-default", "-");
	}
}

class Usuario {
	constructor(nombre, apellidos, email, usuario, password) {
		this._nombre = nombre;
		this._apellidos = apellidos;
		this._email = email;
		this._usuario = usuario;
		this._password = password;
	}
}

class UsuariosApi {
	constructor() {
		this._urlBase = "http://104.236.5.232/api";
		this._apiClient = new ApiClient();
		this._url = "/users";
	}

	getDeUsuarios() {
		let urlCompleta = this._urlBase + this._url;
		let promise = this._apiClient.get(urlCompleta).then(
			(respuesta) => {
				let arrayUsuarios = [];

				for(let i=0; i<respuesta.length; i++) {
					arrayUsuarios.push(this.getUsuarioDeObjeto(respuesta[i]));
				}

				return arrayUsuarios;
			}
		);

		return promise;
	}

	postDeUsuarios(usuario) {
		let urlCompleta = this._urlBase + this._url;
		let params = this.armaParametros(alimento);
		let promise = this._apiClient.post(urlCompleta, params).then(
			(respuesta) => {
				return respuesta;
			}
		);

		return promise;
	}

	deleteDeUsuarios(id) {
		let urlCompleta = this._urlBase + this._url + "/" + id;

		let promise = this._apiClient.del(urlCompleta).then(
			(respuesta) => {
				return respuesta;
			}
		);

		return promise;
	}

	putDeUsuarios(usuario) {
		let urlCompleta = this._urlBase + this._url + "/" + usuario._password;
		let params = this.armaParametros(alimento);
		let promise = this._apiClient.put(urlCompleta, params).then(
			(respuesta) => {
				return respuesta;
			}
		);

		return promise;
	}

	armaParametros(usuario) {
		return {
			email: usuario._password,
			apellidos: usuario._apellidos,
			nombre: usuario._nombre,
			username: usuario._usuario,
			password: usuario._password
		}
	}

	getUsuarioDeObjeto(objeto) {
		return new Usuario(objeto.nombre, objeto.apellidos, objeto.email, objeto.username, objeto.password);
	}
}

window.onload = function() {
	app = new Aplicacion();
	app.iniciar();
}