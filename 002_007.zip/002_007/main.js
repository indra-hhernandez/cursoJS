//Definiendo persona
var Persona = function(nombre) {
    this._nombre = nombre;
    this._dispositivos = [];
}

//Definiendo dispositivo
var Dispositivo = function(id, numero) {
    this._idIphone = id;
    this._numero = numero;
}

Dispositivo.prototype.enviarMensaje = function(idReceptor) {
    var mensaje = getMensaje(this._idIphone).trim();

    if(mensaje != "") {
        pubsub.pub('mensaje', new Mensaje(this._idIphone, idReceptor, mensaje));
    }
}

Dispositivo.prototype.recibirMensaje = function(mensaje) {
    var esPropio = (mensaje._idEmisor == this._idIphone);
    var receptor = esPropio ? this._idIphone : mensaje._idReceptor;
    pintarMensaje(receptor, mensaje._mensaje, esPropio);
}

//Definiendo mensaje
var Mensaje = function(idEmisor, idReceptor, mensaje) {
    this._idEmisor = idEmisor;
    this._idReceptor = idReceptor;
    this._mensaje = mensaje;
}

//Definiendo pubsub
var pubsub = (function() {
    var suscriptores = {};

    function subscribe(event, callback) {
        if(!suscriptores[event]) {
            var suscriptorArray = [callback];
            suscriptores[event] = suscriptorArray;
        } else {
            suscriptores[event].push(callback);
        }
    }

    function publish(event, data) {
        if(suscriptores[event]) {
            suscriptores[event].forEach(function(callback) {
                callback(data);
            });
        }
    }
    return {
        pub: publish,
        sub: subscribe
    };
}());

enviarMensaje = function(idIphone) {
    if(idIphone == "iphone1") {
        dispositivo1.enviarMensaje("iphone2");
    } else {
        dispositivo2.enviarMensaje("iphone1");
    }
}

//Definiendo objetos
var dispositivo1 = new Dispositivo("iphone1", "55349383");
var dispositivo2 = new Dispositivo("iphone2", "55097899");

var persona1 = new Persona("chancho1");
var persona2 = new Persona("chancho2");

persona1._dispositivos.push(dispositivo1);
persona2._dispositivos.push(dispositivo2);

pubsub.sub('mensaje', (function(data) {dispositivo1.recibirMensaje(data)}));
pubsub.sub('mensaje', (function(data) {dispositivo2.recibirMensaje(data)}));