var zoo = {
	nombre: "Zoo-logic",
	ubicacion: {},
	areas: [],
	aforo: 120,
	horaEntrada: 8,
	horaCierre: 18
}

zoo.ubicacion = {
	direccion: "Puerta negra",
	ciudad: "CDMX",
	pais: "México",
	cp: 03200
}

//Reptiles
var areaReptiles = {
	nombre: "Reptiles",
	aforoMaximoArea: 30,
	recintos: [],
	empleados: 10
}

var recintoSerpientes = {
	nombre: "Serpientes",
	aforomaximoRecinto: 10,
	animales: []
}

var Piton  = {
	nombre: "Juan",
	especie: "Piton",
	edad: 3,
	horacomida: 12,
	estadosalud: 3,
	hambre: 8
}

var Boa  = {
	nombre: "Marta",
	especie: "Boa",
	edad: 3,
	horacomida: 14,
	estadosalud: 4,
	hambre: 7
}

var recintoViboras = {
	nombre: "Víboras",
	aforomaximoRecinto: 10,
	animales: []
}

var Mamba  = {
	nombre: "Diego",
	especie: "Mamba Negra",
	edad: 2,
	horacomida: 10,
	estadosalud: 5,
	hambre: 4
}

var Cascabel  = {
	nombre: "Pedro",
	especie: "Cascabel",
	edad: 3,
	horacomida: 16,
	estadosalud: 2,
	hambre: 9
}

//Mamiferos
var areaMamiferos = {
	nombre: "Mamiferos",
	aforoMaximoArea: 50,
	recintos: [],
	empleados: 15
}

var recintoFelinos = {
	nombre: "Felinos",
	aforomaximoRecinto: 10,
	animales: []
}

var Leon  = {
	nombre: "Hugo",
	especie: "Leon",
	edad: 2,
	horacomida: 16,
	estadosalud: 2,
	hambre: 6
}

var Tigre  = {
	nombre: "Luis",
	especie: "Tigre de Bengala",
	edad: 6,
	horacomida: 16,
	estadosalud: 3,
	hambre: 10
}

var recintoHerbiboros = {
	nombre: "Herbiboros",
	aforomaximoRecinto: 10,
	animales: []
}

var Elefante  = {
	nombre: "Sergio",
	especie: "Elefante Africano",
	edad: 23,
	horacomida: 13,
	estadosalud: 4,
	hambre: 8
}

var Jirafa  = {
	nombre: "Josefina",
	especie: "Jirafa",
	edad: 8,
	horacomida: 10,
	estadosalud: 3,
	hambre: 5
}

//Aves
var areaAves = {
	nombre: "Aves",
	aforoMaximoArea: 40,
	recintos: [],
	empleados: 12
}

var recintoDepredadores = {
	nombre: "Depredadores",
	aforomaximoRecinto: 10,
	animales: []
}

var Aguila  = {
	nombre: "Brandon",
	especie: "Aguila Calva",
	edad: 5,
	horacomida: 13,
	estadosalud: 1,
	hambre: 9
}

var Halcon  = {
	nombre: "Mario",
	especie: "Halcon",
	edad: 4,
	horacomida: 10,
	estadosalud: 5,
	hambre: 2
}

var recintoCaronieros = {
	nombre: "Caroñeros",
	aforomaximoRecinto: 10,
	animales: []
}

var Zopilote  = {
	nombre: "Saulo",
	especie: "Zopilote",
	edad: 7,
	horacomida: 11,
	estadosalud: 4,
	hambre: 8
}

zoo.areas.push(areaReptiles);
zoo.areas[0].recintos.push(recintoSerpientes);
zoo.areas[0].recintos[0].animales.push(Piton);
zoo.areas[0].recintos[0].animales.push(Boa);

zoo.areas[0].recintos.push(recintoViboras);
zoo.areas[0].recintos[1].animales.push(Mamba);
zoo.areas[0].recintos[1].animales.push(Cascabel);

zoo.areas.push(areaMamiferos);
zoo.areas[1].recintos.push(recintoFelinos);
zoo.areas[1].recintos[0].animales.push(Leon);
zoo.areas[1].recintos[0].animales.push(Tigre);

zoo.areas[1].recintos.push(recintoHerbiboros);
zoo.areas[1].recintos[1].animales.push(Elefante);
zoo.areas[1].recintos[1].animales.push(Jirafa);

zoo.areas.push(areaAves);
zoo.areas[2].recintos.push(recintoDepredadores);
zoo.areas[2].recintos[0].animales.push(Aguila);
zoo.areas[2].recintos[0].animales.push(Halcon);

zoo.areas[2].recintos.push(recintoCaronieros);
zoo.areas[2].recintos[1].animales.push(Zopilote);

