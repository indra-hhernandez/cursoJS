var media = {
	intentos: 0,
	suma: 0,
	promedio: 0
}

var resultado = {
	longitud: 0,
	frase: '',
}

var mayorLongitud = function(arrayDatos) {
	var frase = "";
	var longitudMayor = 0;
	var indice = 0;
	
	for(var i=0; i<arrayDatos.length; i++) {
	  if (typeof(arrayDatos[i]) == 'string') {
		  if (arrayDatos[i].length > longitudMayor) {
  			longitudMayor = arrayDatos[i].length;
	  		indice = i;
		  }
	  }
	 }

	 resultado.longitud = longitudMayor;
	 resultado.frase = arrayDatos[indice];

	 media.intentos++;
	 media.suma += resultado.longitud;
	 media.promedio = media.suma / media.intentos;

	return resultado;
}

console.log(mayorLongitud(['Hola', 783823, 'Como te va?', 'Bien']));
console.log(mayorLongitud(['Donde estamos', 'Curso de cells', 'Que hacemos', 'Estudiar']));
console.log(mayorLongitud(['México', 'Costa Rica', 'Panama', 'Colombia']));
console.log(mayorLongitud(['Cuando los hijos se van', 'Zapata vive', 'Viva Pancho Villa', 'Arrancame la vida']));
console.log('La media de todos los intentos es: ' + media.promedio);