var resultado = {
	longitud: 0,
	frase: ''
}

var mayorLongitud = function(arrayDatos) {
	var frase = "";
	var longitudMayor = 0;
	var indice = 0;
	
	for(var i=0; i<arrayDatos.length; i++) {
	  if (typeof(arrayDatos[i]) == 'string') {
		  if (arrayDatos[i].length > longitudMayor) {
  			longitudMayor = arrayDatos[i].length;
	  		indice = i;
		  }
	  }
	 }

	 resultado.longitud = longitudMayor;
	 resultado.frase = arrayDatos[indice];

	return resultado;
}

console.log(mayorLongitud(['Hola', 783823, 'Como te va?', 'Bien']));

