var log = x => console.log(x);

var nombresArmas = ["Espada", "Cuchillo", "Hacha", "Lanza", "Cadena", "Mazo"];

function getRandomInteger(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

var Vikingo = function(nombre, salud, potencia, velocidad) {
	this._nombre = nombre;
	this._salud = (typeof salud  == 'undefined') ? getRandomInteger(100, 1000) : salud;
	this._potenciaAtaque = (typeof potencia  == 'undefined') ? getRandomInteger(1, 20) : potencia;
	this._velocidad = (typeof velocidad  == 'undefined') ? getRandomInteger(0, 100) : velocidad;
	this._armas = [];
};

Vikingo.prototype.atacar = function(vikingo) {
	var armaParaUsar = this.useArma();
	var potenciaAtaque = 0;

	if(armaParaUsar) {
		potenciaAtaque = armaParaUsar._potencia;
		if(armaParaUsar._ataques == 0) {
			this.abandonaArma(armaParaUsar);
		}
	} else {
		potenciaAtaque = this._potenciaAtaque;
	}

	vikingo._salud -= potenciaAtaque;
	
	if(armaParaUsar) {
		console.log('Ataca ' + this._nombre + ' (' + armaParaUsar._ataques + '-' + armaParaUsar._tipo + '-' + potenciaAtaque + ') - Salud ' + vikingo._nombre + ':' + vikingo._salud);
	}
	else {
		console.log('Ataca ' + this._nombre + ' (Sin arma -' + potenciaAtaque + ') - Salud ' + vikingo._nombre + ':' + vikingo._salud);
	}
	
	if(vikingo._salud < 0) {
		vikingo._salud = 0;
		console.error('Victoria para ' + this._nombre.toUpperCase() + ' muere ' + vikingo._nombre);
	}
};

Vikingo.prototype.addArma = function(tipo, potencia, ataque) {
	var tipoArma = (typeof tipo  == 'undefined') ? nombresArmas[getRandomInteger(0, 5)] : tipo;
	var potenciaArma = (typeof potencia  == 'undefined') ? getRandomInteger(20, 50) : potencia;
	var ataquesArma = (typeof ataque  == 'undefined') ? getRandomInteger(1, 10) : ataque;
	var arma = new Arma(tipoArma, potenciaArma, ataquesArma);
	this._armas.push(arma);
};

Vikingo.prototype.abandonaArma = function(arma) {
	var indice = this._armas.indexOf(arma);
	this._armas.splice(indice, 1);
};

Vikingo.prototype.useArma = function() {
	var masPotente = 0;
	var armaParaUsar = null;

	if(this._armas.length>0) {
		for(var idx=0;idx<this._armas.length;idx++) {
			var arma = this._armas[idx];
			if(arma._potencia > masPotente) {
				armaParaUsar = arma;
			}
		}

		armaParaUsar._ataques -= 1;
	}
	
	return armaParaUsar;
}

var Batalla = function(vikingo1, vikingo2) {
	this._vikingo1 = vikingo1;
	this._vikingo2 = vikingo2;

	this.armarVikingo(this._vikingo1);
	this.armarVikingo(this._vikingo2);
};

Batalla.prototype.iniciarBatalla = function() {
	var atacaUno = (this._vikingo1._salud > this._vikingo2._salud);
	while(this._vikingo1._salud > 0 && this._vikingo2._salud > 0) {
		if(atacaUno) {
			this._vikingo1.atacar(this._vikingo2);
		} else {
			this._vikingo2.atacar(this._vikingo1);
		}

		atacaUno = !atacaUno;
	}
}

Batalla.prototype.armarVikingo = function(vikingo) {
	var totalArmas = getRandomInteger(1, 3);

	for(var idx=0; idx < totalArmas; idx++) {
		vikingo.addArma();
	}
}

Batalla.prototype.verVikingos = function() {
	console.log(this._vikingo1);
	console.log(this._vikingo2);
}

var Arma = function(tipo, potencia, ataques) {
	this._tipo = tipo;
	this._potencia = potencia;
	this._ataques = ataques;
}

var vikingo1 = new Vikingo("Asterix");
var vikingo2 = new Vikingo("Oberix");
var batalla = new Batalla(vikingo1, vikingo2);

console.log("Fight!");
batalla.verVikingos();
batalla.iniciarBatalla();
console.log("Final:");
batalla.verVikingos();
