var nombrePersonas = ["Victor", "Omar", "Karen", "Ariel", "Omar", "David", "Esteban", "Matías", "Vlairner", "Lucy", "Ignacio", "Humberto", "Nestor", "Daniel", "Raymundo"];

var zoo = {
	nombre: "El último zoológico",
	ubicacion: {},
	areas: [],
	aforo: 70,
	numVisitantes: 0,
	caja: 1000,
	enfermeria: {}
};

var enfermeria = {
	pacientes: []
}

var ubicacion = {
	direccion: "Calle de los animalitos 123",
	ciudad: "Ciudad de México",
	pais: "México",
	telefono: 999888777
}

function creaPaciente(panimal, precinto) {
	return { 
		animal: panimal,
		recinto: precinto
	};
}

function area(nombre, aforo, recintos, animales) {
	return {
		nombre: nombre,
		aforoMaximo: aforo,
		recintos: recintos,
	};
}

function recintoDetalles(nombre, animales, capacidad, detalle){
	return {
		nombre: nombre,
		animales: animales,
		capacidad: capacidad,
		detalle: detalle,
		visitantes: []
	};
}

function animales(nombre, especie, salud, hambre, pais){
	return {
		nombre: nombre,
		especie: especie,
		salud: salud,
		hambre: hambre,
		pais: pais
	};
}

var tigreBlanco = animales("Tigre Blanco", "Felino", 100, 80, "Egipto");
var tigreNormal = animales("Tigre", "Felino", 90, 60, "Africa");

var tigres = [];
tigres.push(tigreBlanco, tigreNormal);

var palomas = animales("Palomas", "Avis Chilensis", 100, 100, "Chile");
var flamencos = animales("Flamenco", "Phoenicopteridae", 10, 0, "Colombia");

var aves = [];
aves.push(palomas, flamencos);

var recinto1 = recintoDetalles("Jaula de tigres", tigres, 10, "Jaula super reforzada con titanium");
var recinto2 = recintoDetalles("Baños", [], 50, "Baños para hombres y mujeres, aptos para personas con discapacidad");
var recinto3 = recintoDetalles("Jaula para aves", aves, 10, "Algunas aves que se pelean a seguido");

var recintoTigres = [];
recintoTigres.push(recinto1, recinto2);

var recintoAves = [];
recintoAves.push(recinto3);

var area1 = area("Mamíferos", 5000, recintoTigres);
var area2 = area("Aves", 200, recintoAves);

zoo.ubicacion = ubicacion;
zoo.enfermeria = enfermeria;
zoo.areas.push(area1, area2);

//log(zoo);


//Funciones








//representa el paso de 1h en el zoo
function ejecutarCiclo() {
	addPersona();
	//console.log("Personas");
	revisionDeAnimales();
	//console.log("Revision Salud");
	atencionEnfermos();
	//console.log("Atencion Enfermos");
	//addHambre(animal, recinto);
	//console.log("Alimentacion");
	//console.log("Ciclo ejecutado");
}

function generarNombreAleatorio() {
	var numeroAleatorio = Math.floor(Math.random() * nombrePersonas.length);
	return nombrePersonas[numeroAleatorio];
}

function generarEdadAleatoria() {
	var edad = Math.floor(Math.random() * 100);
	return edad;
}

function generarMontoAleatorio() {
	var monto = Math.floor(Math.random() * 500);
	return monto;
}

function esEstudianteAleatorio() {
	var esEstudiante = Math.floor(Math.random() * 1);
	return esEstudiante;
}



//añade una persona al parque
function addPersona() {
	if(zoo.numVisitantes < zoo.aforo) {
		//Creamos una nueva persona, le cobramos y le introducimos al parque
		var persona = creaPersona(generarNombreAleatorio(), generarMontoAleatorio(), generarEdadAleatoria(), esEstudianteAleatorio());
		cobrarEntrada(persona);
		var recintoLibre = primerRecintoLibre();
		recintoLibre.visitantes.push(persona);
		zoo.numVisitantes++;
		//Salud
	} else {
		console.log("Zoo lleno!");
		cerrarZoo();
	}
}

//Buscando disponibilidad
function primerRecintoLibre() {
	var recintoLibre = null;

	for(var a=0; a<zoo.areas.length; a++) {
		var area = zoo.areas[a];

		for(var r=0; r<area.recintos.length; r++) {
			var recinto = area.recintos[r];

			if(!recintoLibre && recinto.visitantes.length < recinto.capacidad) {
				recintoLibre = recinto;
			}
		}
	}

	return recintoLibre;
}

//Cobro de entrada
function cobrarEntrada(persona) {
    var importeEntrada = 5;
    
    if(persona.edad < 14 || persona.edad > 65) {
        importeEntrada = 0;
    } else {
        if(persona.estudiante) {
            importeEntrada = 3;
        }
    }

    persona.cartera -= importeEntrada;
    zoo.caja += importeEntrada;
}

//Constructor de Personas
function creaPersona(perNombre, perCartera, perEdad, perEstudiante) {
	return {
		nombre: perNombre,
		cartera: perCartera,
		edad: perEdad,
		estudiante: perEstudiante
	}
}

var intervalID = setInterval(ejecutarCiclo, 1000);

// 1) Crear funcion para cerrar el zoo (parar el intervalo, sacar a todas las personas del zoo)
function cerrarZoo() {
	//Detiene el intervalo
	clearInterval(intervalID);
	//Eliminar visitantes
	for(var a=0; a<zoo.areas.length; a++) {
		var area = zoo.areas[a];

		for(var r=0; r<area.recintos.length; r++) {
			var recinto = area.recintos[r];
			recinto.visitantes = [];
		}
	}
	zoo.numVisitantes = 0;
}

function revisionDeAnimales() {
  for(var a=0; a<zoo.areas.length; a++) {
		var area = zoo.areas[a];

		for(var r=0; r<area.recintos.length; r++) {
			var recinto = area.recintos[r];

			for(var x=0; x<recinto.animales.length; x++) {
				var animal = recinto.animales[x];
				
				modificarSaludAleatoria(animal);
				
				if(animal.salud < 50) {
				  enviarEnfermeria(animal, recinto, x);
				}
				
				addHambre(animal, recinto);
			}
		}
	}
}

// 2)Modificar salud de los animales (-20 a +20, maximo 100) --modificarSaludAleatoria
function modificarSaludAleatoria(animal) {
	var salud = Math.floor(Math.random() * 20);
	var tipo = Math.floor(Math.random() * 1);

	if(tipo == 0) {
		salud = salud * -1;
	} 

	animal.salud += salud;

	if(animal.salud > 100) {
		animal.salud = 100;
	}
}

// 3)En cada ciclo ejecutar modificarSaludAleatoria, si un animal baja 50 de salud deberá ir a la enfermeria
function enviarEnfermeria(animal, recinto, posicion) {
  var paciente = creaPaciente(animal, recinto);
	zoo.enfermeria.pacientes.push(paciente);
	recinto.animales.splice(posicion, 1);
	console.log("enfermo: " + animal.nombre + ':' + animal.salud);
}

// 4)En la enfermeria en cada ciclo los animales recuperan 10 de salud (no se aplica modificarSaludAleatoria)
// 5)Si el animar llega a 100 de salud deberá volver a su área (recordar el área)
function atencionEnfermos() {
	for(var i=0; i<zoo.enfermeria.pacientes.length; i++) {
	  var paciente = zoo.enfermeria.pacientes[i];
	  var animal = paciente.animal;
	  var recinto = paciente.recinto;
	  
	  animal.salud += 10;
	  
	  if (animal.salud >= 100) {
			recinto.animales.push(animal);
		  zoo.enfermeria.pacientes.splice(i, 1);
		  console.log("sano: " + animal.nombre + ':' + animal.salud);
		}
	}
}

// 6)Función addHambre, en cada ciclo sume 10 al animal. Al llegar a 100 alimentar al animal, el hambre pasa a 0 y el zoo gasta $1000
// 7)Si el zoo no tiene dinero y el hambre del animal llega a 150 se comera un visitante y el zoo se queda con la cartera del visitante.
function addHambre(animal, recinto) {
	animal.hambre += 10;

	if(animal.hambre >= 100) {
		if(zoo.caja >= 1000) {
			zoo.caja -= 1000;
			animal.hambre = 0;
		} 
	}

	if(animal.hambre >= 150 && recinto.visitantes.length > 0) {
	  var persona = recinto.visitantes[0];
	  console.log("comiendo: " + animal.nombre + ' a ' + persona.nombre);
		zoo.cartera += persona.cartera;
		recinto.visitantes.shift();
		animal.hambre = 0;
	}
}

// 8)En cada ciclo los visitantes deberan cambiar al siguiente recinto. Cuando hayan visitado todos abandonaran el parque
