var cuentaCaracter = function(cadena) {
	var arrCadena = [];
	var contador = {
  };
	
	if(typeof(cadena) == 'string') {
	  arrCadena = cadena.split('')
	  
  	for(var i=0; i<arrCadena.length; i++) {
	    if (!contador[arrCadena[i]]) {
		    contador[arrCadena[i]] = 0;
  	  }

    	contador[arrCadena[i]]++;
	  }
	}
	else {
	  contador['error'] = 'No has enviado un string';
	}

	return contador;
};

console.log(cuentaCaracter('Holauieuxdrxctvyuinopáaabbb'));
console.log(cuentaCaracter(8934834));