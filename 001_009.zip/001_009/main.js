function ponerTodasLasLetrasMayusculas(cadena) {
  var org = [];
	var res = "";

	org = cadena.split("");
	for(var indice=0; indice<org.length; indice++) {
    res += cadena[indice].toUpperCase();
	}

	return res;
}

function stringInverso(cadena) {
	var org = [];
	var res = "";

	org = cadena.split("");
	for(var indice=cadena.length-1; indice>=0; indice--) {
		res += cadena[indice];
	}

	return res;
}

function eliminarEspacios(cadena) {
	var org = [];
	var res = "";

	org = cadena.split("");
	for(var indice=0; indice<org.length; indice++) {
	  if(org[indice] !== " ") {
	    res += cadena[indice];
	  }
	}

	return res;
}

function esPalindromo(cadena) {
  var org = "";
  var cmp = "";
  var res = false;
	
	org = ponerTodasLasLetrasMayusculas(cadena);
	org = eliminarEspacios(org);
	cmp = stringInverso(org);
	
	if(org == cmp) {
	  res = true;
	}
	
  return res;
}

console.log(esPalindromo("Arde ya la yedra"));
console.log(esPalindromo("Ana lava lana"));
console.log(esPalindromo("Anita lava la tina"));