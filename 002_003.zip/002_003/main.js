/*
1) realiza una clase ejército que tenga un array de vikingos 

2) realiza una clase soldadoVikingo que herede de vikingo y tenga los métodos necesarios para la lucha 

3) realiza una clase curanderoVikingo que herede de vikingo, añade a la clase ejército un array de curanderos y añade el método resucitar(vikingo), que permitirá recuperar la salud de los soldados muertos en combate. Los curanderos solo podrán resucitar 5 veces

4) añade un método enfrentarEjercitos en la clase batalla, que reciba dos ejércitos y los enfrente entre si.
Enfrentará el primer soldado de cada ejército contra el primer soldado del otro. Cuando mueran vikingos si él ejércitos tiene curanderos, podrán revivir al vikingo.
Si no pueden revivirlo, deberá abandonar el array y pasara a enfrentarse el siguiente 
La batalla acabará cuando uno de los dos ejércitos pierda todos sus soldados.
*/

/*Parametros de los Vikingos:

Salud: 100
Potencia de ataque: aleatorio entre 1 y 20
Numero de armas: aleatorio entre 1 y 5


Parametros de armas:

NumeroDeAtaques: aleatorio entre 1 y 10
Potencia: aleatorio entre 20 y 50


Ejercito:

Numero de soldados: 25
Numero de curanderos: 5

Curanderos:

vecesQuePuedeCurar: 5 (restaura a un vikingo al 100% de salud)
*/

//Definiendo constantes
var saludVikingo = 100;
var totalResurecciones = 5;
var totalSoldados = 25;
var totalCuranderos = 5;
var maximoArmas = 5;
var nombresArmas = ["Espada", "Cuchillo", "Hacha", "Lanza", "Cadena", "Mazo"];
var nombreVikingos = ["Victor", "Omar", "Karen", "Ariel", "Omar", "David", "Esteban", "Matías", "Vlairner", "Lucy", "Ignacio", "Humberto", "Nestor", "Daniel", "Raymundo"];

//Definiendo funciones globales
function getRandomInteger(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generarNombreAleatorio() {
	var numeroAleatorio = Math.floor(Math.random() * nombreVikingos.length);
	return nombreVikingos[numeroAleatorio];
}

//Definiendo ejercito
var Ejercito = function(nombre) {
	this._nombre = nombre
	this._soldados = [];
	this._curanderos = [];
};

Ejercito.prototype.armarSoldado = function(soldado) {
	var totalArmas = getRandomInteger(1, maximoArmas);

	for(var idx=0; idx < totalArmas; idx++) {
		soldado.addArma();
	}
}

Ejercito.prototype.obtenerCuracion = function() {
	var existeCura = false;

	if(this._curanderos.length > 0) {
		var curandero = this._curanderos[this._curanderos.length-1];
		if(curandero._curaciones > 0) {
			curandero._curaciones--;
			existeCura = true;

			if(curandero._curaciones == 0) {
				this._curanderos.pop();
			}
		}
		else {
			this._curanderos.pop();
		}
	}

	return existeCura;
}

//Definiendo Vikingo
var Vikingo = function() {
	this._nombre = "";
	this._salud = saludVikingo;
};

Vikingo.prototype.initVikingo = function() {
	this._nombre = generarNombreAleatorio();
}

//Definiendo SoldadoVikingo
var SoldadoVikingo = function(potencia, velocidad) {
	this._potenciaAtaque = (typeof potencia  == 'undefined') ? getRandomInteger(1, 20) : potencia;
	this._velocidad = (typeof velocidad  == 'undefined') ? getRandomInteger(0, 100) : velocidad;
	this._armas = [];
};

SoldadoVikingo.prototype = new Vikingo();

SoldadoVikingo.prototype.atacar = function(vikingo) {
	var armaParaUsar = this.elegirArma();
	var potenciaAtaque = 0;

	if(armaParaUsar) {
		potenciaAtaque = armaParaUsar._potencia;
		if(armaParaUsar._ataques == 0) {
			this.abandonaArma(armaParaUsar);
		}
	} else {
		potenciaAtaque = this._potenciaAtaque;
	}

	vikingo._salud -= potenciaAtaque;
	
	//Log para estatus de ataque y muerte
	if(armaParaUsar) {
		console.log('Ataca ' + this._nombre + ' (' + armaParaUsar._ataques + '-' + armaParaUsar._tipo + '-' + potenciaAtaque + ') - Salud ' + vikingo._nombre + ':' + vikingo._salud);
	}
	else {
		console.log('Ataca ' + this._nombre + ' (Sin arma -' + potenciaAtaque + ') - Salud ' + vikingo._nombre + ':' + vikingo._salud);
	}
	
	if(vikingo._salud <= 0) {
		vikingo._salud = 0;
		console.error('Victoria para ' + this._nombre.toUpperCase() + ' muere ' + vikingo._nombre);
	}
};

SoldadoVikingo.prototype.addArma = function(tipo, potencia, ataque) {
	var arma = new Arma(tipo, potencia, ataque);
	this._armas.push(arma);
};

SoldadoVikingo.prototype.abandonaArma = function(arma) {
	var indice = this._armas.indexOf(arma);
	this._armas.splice(indice, 1);
};

SoldadoVikingo.prototype.elegirArma = function() {
	var masPotente = 0;
	var armaParaUsar = null;

	if(this._armas.length>0) {
		for(var idx=0;idx<this._armas.length;idx++) {
			var arma = this._armas[idx];
			if(arma._potencia > masPotente) {
				armaParaUsar = arma;
			}
		}

		armaParaUsar._ataques -= 1;
	}
	
	return armaParaUsar;
};

SoldadoVikingo.prototype.robarArmas = function(vikingo) {
    if (vikingo._armas.length) {
        this._armas = this._armas.concat(vikingo._armas);
        console.warn(this._nombre + " ha robado " + vikingo._armas.length + " armas a " + vikingo._nombre);
        vikingo._armas = [];
    }
};

//Definiendo CuranderoVikingo
var CuranderoVikingo = function(curaciones) {
	this._curaciones = (typeof curaciones  == 'undefined') ? totalResurecciones : curaciones;
};

CuranderoVikingo.prototype = new Vikingo();

//Definiendo Batalla
var Batalla = function(ejercito1, ejercito2) {
	this._ejercito1 = ejercito1;
	this._ejercito2 = ejercito2;
};

Batalla.prototype.iniciarBatalla = function() {
	while(this._ejercito1._soldados.length > 0 && this._ejercito2._soldados.length > 0) {
		var soldado1 = this._ejercito1._soldados[this._ejercito1._soldados.length-1];
		var soldado2 = this._ejercito2._soldados[this._ejercito2._soldados.length-1];
		
		this.iniciarPelea(soldado1, soldado2);

		var ejercitoPerdedor = (soldado1._salud < soldado2._salud) ? this._ejercito1 : this._ejercito2;
		var soldadoPerdedor = (soldado1._salud < soldado2._salud) ? soldado1 : soldado2;
		var soldadoGanador = (soldado1._salud > soldado2._salud) ? soldado1 : soldado2;

		if(ejercitoPerdedor.obtenerCuracion()) {
			soldadoPerdedor._salud = saludVikingo;
			if(ejercitoPerdedor._curanderos.length > 0) {
				console.warn("Resucita " + soldadoPerdedor._nombre + '(' + (((ejercitoPerdedor._curanderos.length-1) * 5) + ejercitoPerdedor._curanderos[ejercitoPerdedor._curanderos.length-1]._curaciones) + ')');
			}
		} else {
			soldadoGanador.robarArmas(soldadoPerdedor);
			ejercitoPerdedor._soldados.pop();
		}
	}
}

Batalla.prototype.iniciarPelea = function(soldado1, soldado2) {
	var atacaUno = (soldado1._salud > soldado2._salud);
	while(soldado1._salud > 0 && soldado2._salud > 0) {
		if(atacaUno) {
			soldado1.atacar(soldado2);
		} else {
			soldado2.atacar(soldado1);
		}

		atacaUno = !atacaUno;
	}
}

var Arma = function(tipo, potencia, ataque) {
	this._tipo = (typeof tipo  == 'undefined') ? nombresArmas[getRandomInteger(0, 5)] : tipo;
	this._potencia = (typeof potencia  == 'undefined') ? getRandomInteger(20, 50) : potencia;
	this._ataques = (typeof ataque  == 'undefined') ? getRandomInteger(1, 10) : ataque;
}

//Reclutando Ejercitos aleatorio
function reclutaEjercitoAleatorio(nombre) {
	var ejercito = new Ejercito(nombre);

	for(idx=0; idx<totalSoldados; idx++) {
		var soldado = new SoldadoVikingo();
		soldado.initVikingo();
		ejercito.armarSoldado(soldado);
		ejercito._soldados.push(soldado);
	}

	for(idx=0; idx<totalCuranderos; idx++) {
		var curandero = new CuranderoVikingo();
		curandero.initVikingo();
		ejercito._curanderos.push(curandero);
	}

	return ejercito;
}

//Reclutando EjercitosMejorado
function reclutaEjercitoMejorado(nombre) {
	var ejercito = new Ejercito(nombre);
	var armas = [];

	//Genera armas
	for(idx=0; idx<50; idx++) {
		armas.push(new Arma());
	}

	//Genera Soldados
	for(idx=0; idx<totalSoldados; idx++) {
		var soldado = new SoldadoVikingo();
		soldado.initVikingo();
		ejercito._soldados.push(soldado);
	}

	//Genera Curanderos
	for(idx=0; idx<totalCuranderos; idx++) {
		var curandero = new CuranderoVikingo();
		curandero.initVikingo();
		ejercito._curanderos.push(curandero);
	}

	//Orden de armas
	armas.sort(function(a, b) { return (a._potencia * a._ataques) - (b._potencia * b._ataques)});

	//Orden Soldados
	ejercito._soldados.sort(function(a, b) { return a._velocidad - b._velocidad});
	ejercito._soldados.sort(function(a, b) { return a._potenciaAtaque- b._potenciaAtaque});

	//RepartirArmas
	for(idx=0; idx<50; idx++) {
		if(idx<20) {
			ejercito._soldados[Math.floor(idx/4)]._armas.push(armas[idx]);
		} else if(idx<40) {
			var soldado = ejercito._soldados[Math.floor((idx-10)/2)]._armas.push(armas[idx]);
		} else {
			var soldado = ejercito._soldados[idx-25]._armas.push(armas[idx]);
		}
	}

	return ejercito;
}

Batalla.prototype.verEjercito = function() {
	console.log(ejercitoNorte);
	console.log(ejercitoSur);
}

Batalla.prototype.verVikingos = function() {
	console.log(this._vikingo1);
	console.log(this._vikingo2);
}

var ejercitoNorte = reclutaEjercitoMejorado("Norte");
var ejercitoSur = reclutaEjercitoMejorado("Sur");
var batalla = new Batalla(ejercitoNorte, ejercitoSur);

console.log("Fight!");
batalla.verEjercito();
batalla.iniciarBatalla();
console.log("Final:");

if(ejercitoNorte._soldados.length > 0) { 
	console.log("Vencedor: " + ejercitoNorte._nombre.toUpperCase());
} else {
	console.log("Vencedor: " + ejercitoSur._nombre.toUpperCase());
}