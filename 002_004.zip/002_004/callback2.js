function loadScript(src, callback) {
	var elem = document.createElement('script');
	elemen.setAttribute('type', 'text/javascript');
	elemen.setAttribute('src', src);
	elem.onload = function() { calback(null, src) };
	elemen.onerror = function() { callback("Error al cargar " + src, null) };
	document.documentElement.insertBefore(elem, null);
}

function miCallBackConErrorHandling(error, data) {
	if(error) {
		console.error(error);
	} else {
		console.log("Genial, hemos cargado: " + data);
		console.log(jQuery);
	}
}

function testCallBack() {
	loadScript('https://code.jquery.com/jquery-3.2.1.slim.min.js', miCallBack);
}

function testCallBackConError() {
	loadScript('https://urlque.noexiste', miCallBackConErrorHandling);
}