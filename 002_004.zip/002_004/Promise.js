var promiseCount = 0;

function testPromise() {
	var thisPromiseCount = ++promiseCount;

	console.log(thisPromiseCount + " Comenzó la ejecución del código principal");

	var p1 = new Promise(
		function(resolve, reject) {
			console.log(thisPromiseCount + " Comenzó la promesa a ejecutar");

			setTimeout(
				function() {
					var numAleatorio = Math.floor(Math.random() * 4);

					if(numAleatorio == 1) {
						reject("Error");
					} else {
						resolve(thisPromiseCount);
					}
				}, Math.random() * 3000 + 2000);
		}
	);

	p1.then(
		function(val) {
			console.log(val + " La promesa se ha cumplido");
		}
	)
	.catch(
		function(reason) {
			console.log('Manejar promesa rechazada ('+reason+') aquí.');
		}
	);
	console.log(thisPromiseCount + " Fin del código principal");
}

for(var i=0; i<10; i++) {
	testPromise();	
}