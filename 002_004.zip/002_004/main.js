/*
Ejercicio 002__004

1) Define una clase Persona que tenga los siguientes atributos:
Nombre: 
Edad:    (15-50)
Nacionalidad:
Altura: 
Peso:
Enfermo: true/false - ​El estar enfermo o no, es aleatorio (10% de probabilidad)

2) Definir la clase Jugador que herede de persona y tenga los siguientes atributos:
Posición: (portero/defensa/mediocentro/delantero) - La posición en la que juegan es completamente aleatoria
Numero: 
Calidad: (0-100)

3) Definir la clase Equipo que tenga:
- Array de jugadores
- Entrenador 
*Un equipo tendrá 22 jugadores creados aleatoriamente

4) Definir la clase Entrenador que herede de Persona y tenga los siguientes métodos:
- elegirPlantillaParaPartido() que elegirá de sus jugadores a los mejores para un partido:
    1 portero
    4 defensas
    4 mediocentros
    2 delanteros
*/    

//Definiendo Globales
var posPortero = "portero";
var posDefensa = "defensa";
var posMedio = "mediocentro";
var posDelantero = "delantero";

var nombresPersona = ["Javier", "Luis", "Carlos", "Roberto", "Sergio"];
var nacionalidadPersona = ["Mexicano", "Chileno", "Ruso", "Aleman", "Portugues"];
var posicionJugador = [posPortero, posDefensa, posMedio, posDelantero];

function getRandomInteger(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generarStringAleatorio(arregloString) {
	var numeroAleatorio = Math.floor(Math.random() * arregloString.length);
	return arregloString[numeroAleatorio];
}

//Definiendo Persona
var Persona = function() {
	this._nombre = "";
	this._edad = 0;
	this._nacionalidad = "";
	this._altura = 0;
	this._peso = 0;
	this._enfermo = false;
}

Persona.prototype.initPersona = function(nombre, edad, nacionalidad, altura, peso, enfermo) {
	this._nombre = generarStringAleatorio(nombresPersona);
	this._edad = getRandomInteger(15, 50);
	this._nacionalidad = generarStringAleatorio(nacionalidadPersona);
	this._altura = getRandomInteger(160, 210);
	this._peso = getRandomInteger(50, 100);
	this._enfermo = getRandomInteger(1, 10) == 1 ? true : false;
}

//Definiendo Jugador
var Jugador = function() {
	this._posicion = generarStringAleatorio(posicionJugador);
	this._numero = 0;
	this._calidad = getRandomInteger(0, 100);
}

Jugador.prototype = new Persona();

//Definiendo Entrenador
var Entrenador = function() {
}

Entrenador.prototype = new Persona();

Entrenador.prototype.elegirAlineacion = function(plantilla) {
	var alineacion = new Alineacion(4, 4, 2);

	//ordenar descendente por calidad
	plantilla.sort(function(a,b) {return b._calidad - a._calidad});
	//Seleccion por posicion
	this.seleccionarPosicion(plantilla, alineacion, true);
	//Seleccion por calidad
	this.seleccionarPosicion(plantilla, alineacion, false);
	//Seleccion totales de evaluacion
	alineacion.evaluacion();

	return alineacion;
}

Entrenador.prototype.seleccionarPosicion = function(plantilla, alineacion, porPosicion) {
	var posicion = "";
	
	for(var idx=0; idx<posicionJugador.length; idx++) {
		posicion = porPosicion ? posicionJugador[idx] : "*";
		this.seleccionarJugadores(plantilla, alineacion["_"+posicionJugador[idx]+"s"], posicion, alineacion["_total"+posicionJugador[idx]+"s"]);
	}
}

Entrenador.prototype.seleccionarJugadores = function(plantilla, grupo, posicion, total, enfermo) {
	for(var idx=0; idx<plantilla.length; idx++) {
		var jugador = plantilla[idx];
		if(grupo.length < total && jugador._numero == 0 && (posicion == "*" || posicion == jugador._posicion)) {
			jugador._numero = 1;
			grupo.push(jugador);
		}
	}
}

//Definiendo Equipo
var Equipo = function() {
	this._plantilla = [];
	this._entrenador = new Entrenador();
	this._entrenador.initPersona();
	this._alineacion = new Alineacion();
}

Equipo.prototype.cargarPlantilla = function() {
	var numeroJugadores = 22;

	for(var idx=0; idx<22; idx++) {
		var jugador = new Jugador();
		jugador.initPersona();
		this._plantilla.push(jugador);
	}
}

//Definiendo Alineacion
var Alineacion = function(defensas, medios, delanteros) {
	this._porteros = [];
	this._defensas = [];
	this._mediocentros = [];
	this._delanteros = [];

	this._totalporteros = 1;
	this._totaldefensas = defensas;
	this._totalmediocentros = medios;
	this._totaldelanteros = delanteros;

	this._calidadmediocentros = 0;
	this._calidaddelanteros;
	this._calidadporteros =  0;
	this._calidaddefensas =  0;
	this._fueraLugar = 0;
}

Alineacion.prototype.evaluacion = function() {
	for(var idx=0; idx<posicionJugador.length; idx++) {
		this["_calidad"+posicionJugador[idx]+"s"] = this.evaluar(this["_"+posicionJugador[idx]+"s"]);
		this._fueraLugar += this.fueraDeLugar(this["_"+posicionJugador[idx]+"s"], posicionJugador[idx]);
	}
}

Alineacion.prototype.evaluar = function(grupo) {
	var calidad = 0;
	
	for(var idx=0; idx<grupo.length; idx++) {
		calidad += grupo[idx]._calidad;
	}

	return calidad;
}

Alineacion.prototype.fueraDeLugar = function(grupo, posicion) {
	var total = 0;
	
	for(var idx=0; idx<grupo.length; idx++) {
		if(grupo[idx]._posicion != posicion) {
			total++;
		}
	}

	return total;
}

//Definiendo Partido
var Partido = function(alineacion1, alineacion2) {
	this._alineacion1 = alineacion1;
	this._alineacion2 = alineacion2;

	this._estadistica1 = new Estadistica();
	this._estadistica2 = new Estadistica();
}

//Definiendo estadistica de juego por equipo
var Estadistica = function() {
	this._gana = false;
	this._goles = 0;
	this._poste = 0;
	this._fallo = 0;
}

Estadistica.prototype.resultadoJugada = function(valorJugada) {
	if(valorJugada > 0) {
		this._goles++;
	} else if(valorJugada < 0) {
		this._fallo++;
	} else {
		this._poste++;
	}
}

Estadistica.prototype.resultado = function(estadisticaContraria) {
	this._gana = (this._goles > estadisticaContraria._goles);
}

Partido.prototype.juego = function() {
	for(var idx=0; idx<10; idx++) {
		this.jugada(this._alineacion1, this._alineacion2, this._estadistica1);
		this.jugada(this._alineacion2, this._alineacion1, this._estadistica2);
	}

	this._estadistica1.resultado(this._estadistica2);
	this._estadistica2.resultado(this._estadistica1);
}

Partido.prototype.jugada = function(alineacion1, alineacion2, estadistica) {
	var valorJugada = 0;
	
	valorJugada += alineacion1._calidadmediocentros - alineacion2._calidadmediocentros;
	valorJugada += alineacion1._calidaddelanteros - alineacion2._calidaddefensas;
	valorJugada += -(alineacion2._calidadporteros);
	valorJugada += (alineacion1._fueraLugar * -10) + (alineacion2._fueraLugar * 10);
	valorJugada += getRandomInteger(0, 200);

	estadistica.resultadoJugada(valorJugada);
	console.log(valorJugada + " * " + ((valorJugada > 0) ? "GOOOOOOOL! " : ((valorJugada < 0) ? "Ná de ná" : "PALO !!!")));
}

Partido.prototype.verResultado = function() {
	var resultado = "";
	if(this._estadistica1._gana) {
		resultado = "Equipo 1 GANADOR";
	} else if(this._estadistica2._gana) {
		resultado = "Equipo 2 GANADOR";
	} else {
		resultado = "Empate";
	}

	return resultado + ", total de goles: " + this._estadistica1._goles + "-" + this._estadistica2._goles;
}

/*
A = (Suma de calidad de medio centros equipo 1) - (Suma de calidad de medio centros equipo 2)
B = (Suma de calidad de delanteros 1) - (Suma de calidad de defensas equipo 2)
C = A + B - (Suma de calidad de portero equipo B)
Fortuna = numero aleatorio entre 0 y 100
Para cada jugador que no esté en su puesto del equipo 1: 
C = C - 10
Para cada jugador que no esté en su puesto del equipo 2: 
C = C + 10
TOTAL = C + Fortuna

Si total es mayor que cero -> GOOOOOOOL
Si total es igual a cero -> PALO !!!
Si total es menor que cero -> Ná de ná​ 
*/

//Se crean los equipos
var equipo1 = new Equipo();
var equipo2 = new Equipo();

//Se carga plantilla aleatoria 22 jugadores
equipo1.cargarPlantilla();
equipo2.cargarPlantilla();

//Cada entrenador elige una alineacion
equipo1._alineacion = equipo1._entrenador.elegirAlineacion(equipo1._plantilla);
equipo2._alineacion = equipo2._entrenador.elegirAlineacion(equipo2._plantilla);

//Celebrando partido
var partido = new Partido(equipo1._alineacion, equipo2._alineacion);
partido.juego();

//Mostrando resultado
console.log(partido);
console.log(partido.verResultado());