var functionSuperLenta = function(FuncionDeFin) {
	var acumulado = 0;
	
	for(var i=0; i<1000; i++) {
		acumulado = acumulado + 1;
		console.log(acumulado);
	}

	FuncionDeFin(acumulado);
}

var miCallBack = function(resultado) {
	alert("He acabado!! " + resultado);
}

functionSuperLenta(miCallBack);